package com.mapaoffline.gps

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.mapaoffline.gps.bus.BusData
import com.mapaoffline.gps.bus.BusRouter
import com.mapaoffline.gps.nav.NavData
import com.mapaoffline.gps.nav.Route
import com.mapaoffline.gps.nav.RutaException
import com.mapaoffline.gps.nav.Router
import com.mapaoffline.gps.nav.Searcher
import org.mapsforge.core.model.LatLong
import org.mapsforge.core.model.Point
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.layer.cache.TileCache
import org.mapsforge.map.layer.overlay.Marker
import org.mapsforge.map.layer.overlay.Polyline
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.rendertheme.InternalRenderTheme
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Fase 1: mapa sin conexión + ubicación GPS.
 * - El mapa se baja una vez con internet (o se elige un archivo .map) y después se usa sin conexión.
 * - La ubicación viene del GPS del teléfono y no se envía a ningún lado.
 */
class MapActivity : Activity() {

    private enum class Estado { SIN_MAPA, BAJANDO, LISTO }

    private val main = Handler(Looper.getMainLooper())

    private lateinit var mapView: MapView
    private lateinit var estado: TextView
    private lateinit var panel: LinearLayout
    private lateinit var botones: LinearLayout

    private var tileCache: TileCache? = null
    private var capaMapa: TileRendererLayer? = null
    private var marcador: Marker? = null
    private var ubicacion: Location? = null
    private var ultimaFijacion = 0L
    private var seguir = true
    private var mapaActual: File? = null

    private var estadoApp = Estado.SIN_MAPA
    private var bajada: Downloader? = null
    private var barra: ProgressBar? = null
    private var textoProgreso: TextView? = null
    private var mensajeError: String? = null
    private var tituloBajada: TextView? = null
    private var bajandoRutas = false

    // rutas y buscador (se cargan del archivo .nav del mapa)
    private class NavKit(val datos: NavData, val router: Router, val buscador: Searcher)
    private var navKit: NavKit? = null
    private var busRouter: BusRouter? = null
    private var planesBus: List<BusRouter.Plan> = emptyList()
    private var planBusActual = 0
    private val capasBus = ArrayList<org.mapsforge.map.layer.Layer>()
    private var cargandoNav = false

    private lateinit var arriba: LinearLayout
    private lateinit var campo: EditText
    private lateinit var scrollResultados: ScrollView
    private lateinit var listaResultados: LinearLayout
    private lateinit var panelRuta: LinearLayout
    private lateinit var bannerNav: LinearLayout
    private lateinit var velArriba: TextView
    private lateinit var botonMic: Button
    private lateinit var contenedorMapa: FrameLayout
    private var rotacionAuto = true
    private var rotacionMapa = 0f
    private var anguloDedos = Float.NaN
    private var ultimoCambioZoom = 0L
    private var pausaZoomHasta = 0L
    private val retomarSeguimiento = Runnable {
        if (navegando) {
            seguir = true
            ubicacion?.let { centrarSeguimiento(it) }
        }
    }
    private lateinit var velNav: TextView
    private lateinit var flechaNav: TextView
    private lateinit var distNav: TextView
    private lateinit var textoNav: TextView
    private var resumenNav: TextView? = null
    private var botonVoz: TextView? = null
    private var botonNoche: TextView? = null
    private var noche = false

    /** Modo noche: invierte el brillo del mapa y lo oscurece un poco, sin cambiar los colores de base. */
    private fun aplicarNoche() {
        try {
            if (noche) {
                val inv = android.graphics.ColorMatrix(floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                ))
                val hue = android.graphics.ColorMatrix(floatArrayOf(
                    -0.574f, 1.430f, 0.144f, 0f, 0f,
                    0.426f, 0.430f, 0.144f, 0f, 0f,
                    0.426f, 1.430f, -0.856f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                ))
                inv.postConcat(hue)
                val tenue = android.graphics.ColorMatrix()
                tenue.setScale(0.85f, 0.85f, 0.85f, 1f)
                inv.postConcat(tenue)
                val paint = android.graphics.Paint()
                paint.colorFilter = android.graphics.ColorMatrixColorFilter(inv)
                mapView.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
            } else {
                mapView.setLayerType(View.LAYER_TYPE_NONE, null)
            }
        } catch (e: Throwable) {
        }
        botonNoche?.text = if (noche) "🌙" else "☀"
    }

    private fun alternarNoche() {
        noche = !noche
        getSharedPreferences("mapa", MODE_PRIVATE).edit().putBoolean("noche", noche).apply()
        aplicarNoche()
    }

    private var hayDestino = false
    private var destLat = 0.0
    private var destLon = 0.0
    private var destTitulo = ""
    private var ruta: Route? = null
    private var capaRuta: Polyline? = null
    private var capaDestino: Marker? = null
    private val pines = ArrayList<Marker>()
    private var lugaresPines: List<Searcher.Lugar> = emptyList()
    private lateinit var barraPines: LinearLayout
    private lateinit var textoPines: TextView
    private var calculando = false

    private var navegando = false
    private var segmentoActual = 0
    private var fueraCont = 0
    private var ultimoReruteo = 0L
    private val anunciados = HashSet<Int>()
    private var vozActiva = true
    private var tts: TextToSpeech? = null
    private var ttsListo = false

    // cursor que representa tu posición (se elige en el botón ▲)
    private val estilos = listOf("Punto", "Flecha", "Moto", "Auto", "Camioneta")
    private var cursorEstilo = 1
    private var rumboCursor = 0f
    private var rumboDibujado = -999f
    private var estiloDibujado = -1

    private val lm by lazy { getSystemService(LOCATION_SERVICE) as LocationManager }
    private var gpsActivo = false

    private val oyente = object : LocationListener {
        override fun onLocationChanged(l: Location) { alRecibirUbicacion(l) }
        @Deprecated("Solo para Android anterior a 10")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) { actualizarEstadoGps() }
        override fun onProviderDisabled(provider: String) { actualizarEstadoGps() }
    }

    private val relojVelocidad = object : Runnable {
        override fun run() {
            actualizarVelocidad()
            actualizarMic()
            main.postDelayed(this, 500)
        }
    }

    private val vigilante = object : Runnable {
        override fun run() {
            actualizarEstadoGps()
            main.postDelayed(this, 2000)
        }
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)
        cursorEstilo = getSharedPreferences("mapa", MODE_PRIVATE).getInt("cursor", 1)
        construirPantalla()
        iniciarVoz()
        MapStore.cleanParts(this)
        val guardados = MapStore.installed(this)
        val ultimo = getSharedPreferences("mapa", MODE_PRIVATE).getString("actual", null)
        val elegido = guardados.firstOrNull { it.name == ultimo } ?: guardados.firstOrNull()
        if (elegido != null) abrirMapa(elegido) else mostrarEstado(Estado.SIN_MAPA)
    }

    override fun onStart() {
        super.onStart()
        pedirPermisoYEmpezar()
        main.post(vigilante)
        main.post(relojVelocidad)
    }

    override fun onStop() {
        super.onStop()
        detenerGps()
        main.removeCallbacks(vigilante)
        main.removeCallbacks(relojVelocidad)
    }

    override fun onDestroy() {
        bajada?.cancelar()
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        quitarMapa()
        try { mapView.destroyAll() } catch (e: Exception) { }
        AndroidGraphicFactory.clearResourceMemoryCache()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ pantalla

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    // ------------------------------------------------------------------ velocímetro chico y pestañas

    private fun hayInternet(): Boolean =
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val red = cm.activeNetwork
            val caps = if (red != null) cm.getNetworkCapabilities(red) else null
            caps != null &&
                caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            false
        }

    /** El micrófono se pone rojo cuando no hay internet, porque el reconocimiento de voz lo necesita. */
    private fun actualizarMic() {
        val con = hayInternet()
        botonMic.background = fondo(if (con) 0xFFE3EEF7.toInt() else 0xFFD32F2F.toInt(), 14)
        botonMic.alpha = if (con) 1f else 0.95f
    }

    private fun alTocarMic() {
        if (!hayInternet()) {
            actualizarMic()
            Toast.makeText(this, "Sin internet: el micrófono necesita conexión. Escribí la dirección.", Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Decí una dirección o un lugar")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            startActivityForResult(i, PEDIDO_VOZ)
        } catch (e: Exception) {
            Toast.makeText(this, "Tu celular no tiene reconocimiento de voz.", Toast.LENGTH_LONG).show()
        }
    }

    private fun chipVelocidad(): TextView =
        TextView(this).apply {
            textSize = 22f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(3), dp(10), dp(3))
            text = "--"
        }

    /** Velocidad solo con números digitales, con los mismos valores y colores del velocímetro. */
    private fun actualizarVelocidad() {
        val u = ubicacion
        val v: Float? = if (u != null && u.hasSpeed() && System.currentTimeMillis() - ultimaFijacion < 5000L) u.speed * 3.6f else null
        val mph = false
        val num = if (v == null) "--" else Math.round(if (mph) v * 0.621371f else v).toString()
        val color = Color.WHITE
        val fondoChip = 0xF2000000.toInt()
        for (tv in listOf(velArriba, velNav)) {
            tv.text = num + (if (mph) " mph" else " km/h")
            tv.setTextColor(color)
            tv.background = fondo(fondoChip, 12)
        }
    }

    private fun abrirMenuPestanas(ancla: View) {
        val pm = android.widget.PopupMenu(this, ancla)
        pm.menu.add(0, 10, 0, "⭐ Mis lugares")
        pm.menu.add(0, 11, 1, "🛣 Opciones de ruta")
        pm.menu.add(0, 12, 1, if (noche) "☀ Modo día" else "🌙 Modo noche")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                10 -> abrirMisLugares()
                11 -> abrirOpcionesRuta()
                12 -> alternarNoche()
            }
            true
        }
        pm.show()
    }

    private fun fondo(color: Int, radio: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radio).toFloat()
        }

    private fun texto(t: String, tam: Float, color: Int = Color.WHITE, negrita: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = tam
            setTextColor(color)
            if (negrita) setTypeface(typeface, Typeface.BOLD)
        }

    private fun boton(t: String, principal: Boolean, accion: () -> Unit): Button =
        Button(this).apply {
            text = t
            isAllCaps = false
            textSize = 16f
            setTextColor(if (principal) Color.WHITE else 0xFF0B3D5C.toInt())
            background = fondo(if (principal) 0xFF1976D2.toInt() else 0xFFE3EEF7.toInt(), 14)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { accion() }
        }

    private fun botonRedondo(t: String, accion: () -> Unit): TextView =
        texto(t, 24f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = fondo(0xE60B3D5C.toInt(), 28)
            setOnClickListener { accion() }
        }

    private fun construirPantalla() {
        val raiz = FrameLayout(this)
        raiz.fitsSystemWindows = true

        mapView = MapView(this)
        noche = getSharedPreferences("mapa", MODE_PRIVATE).getBoolean("noche", false)
        aplicarNoche()
        mapView.isClickable = true
        mapView.mapScaleBar.isVisible = true
        mapView.model.mapViewPosition.setZoomLevelMin(8.toByte())
        mapView.model.mapViewPosition.setZoomLevelMax(20.toByte())
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) { alMantener(e.x, e.y) }
        })
        mapView.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_MOVE) {
                seguir = false
                if (navegando) {
                    pausaZoomHasta = System.currentTimeMillis() + 12000L
                    main.removeCallbacks(retomarSeguimiento)
                    main.postDelayed(retomarSeguimiento, 8000L)
                }
            }
            detector.onTouchEvent(ev)
            false
        }
        // El mapa es un cuadrado más grande que la pantalla (su diagonal) para poder girarlo sin que se vean bordes vacíos.
        contenedorMapa = object : FrameLayout(this) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                girarConDedos(ev)
                return super.dispatchTouchEvent(ev)
            }
        }
        val dm = resources.displayMetrics
        val diagonal = Math.ceil(Math.sqrt(dm.widthPixels.toDouble() * dm.widthPixels + dm.heightPixels.toDouble() * dm.heightPixels)).toInt() + dp(8)
        contenedorMapa.addView(mapView, FrameLayout.LayoutParams(diagonal, diagonal, Gravity.CENTER))
        raiz.addView(contenedorMapa, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // barra de arriba: estado del GPS, acceso a los mapas y buscador
        arriba = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fondo(0xE60B3D5C.toInt(), 16)
            setPadding(dp(14), dp(8), dp(8), dp(8))
        }
        val fila1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        // botón chico de la izquierda: pasa a las otras pestañas (Principal, Nafta, Ajustes)
        fila1.addView(
            texto("☰", 22f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = fondo(0x33FFFFFF, 10)
                setPadding(dp(10), dp(2), dp(10), dp(2))
                setOnClickListener { abrirMenuPestanas(this) }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) }
        )
        estado = texto("Iniciando…", 15f)
        fila1.addView(estado, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        velArriba = chipVelocidad()
        fila1.addView(
            velArriba,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) }
        )
        fila1.addView(
            boton("Mapas", false) { mostrarMapas() }.apply { textSize = 14f },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        arriba.addView(fila1)

        val fila2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        campo = EditText(this).apply {
            hint = "Buscar dirección o lugar"
            setHintTextColor(0xFF7A8A99.toInt())
            setTextColor(0xFF14283A.toInt())
            textSize = 16f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = fondo(Color.WHITE, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnEditorActionListener { _, accion, _ ->
                if (accion == EditorInfo.IME_ACTION_SEARCH) {
                    buscar()
                    true
                } else {
                    false
                }
            }
        }
        fila2.addView(campo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        botonMic = boton("🎤", false) { alTocarMic() }.apply {
            textSize = 16f
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        fila2.addView(
            botonMic,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
        )
        fila2.addView(
            boton("Buscar", true) { buscar() }.apply { textSize = 14f },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
        )
        arriba.addView(
            fila2,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
                rightMargin = dp(6)
            }
        )

        barraPines = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        textoPines = texto("", 15f, Color.WHITE, true)
        barraPines.addView(textoPines, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        barraPines.addView(
            boton("Lista", false) { alternarListaPines() }.apply { textSize = 13f; setPadding(dp(12), dp(6), dp(12), dp(6)) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) }
        )
        barraPines.addView(
            boton("Cerrar", false) { quitarPines() }.apply { textSize = 13f; setPadding(dp(12), dp(6), dp(12), dp(6)) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) }
        )
        arriba.addView(
            barraPines,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
                rightMargin = dp(6)
            }
        )

        scrollResultados = object : ScrollView(this) {
            override fun onMeasure(anchoSpec: Int, altoSpec: Int) {
                super.onMeasure(anchoSpec, View.MeasureSpec.makeMeasureSpec(dp(300), View.MeasureSpec.AT_MOST))
            }
        }
        scrollResultados.visibility = View.GONE
        listaResultados = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scrollResultados.addView(listaResultados)
        arriba.addView(
            scrollResultados,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
                rightMargin = dp(6)
            }
        )
        raiz.addView(
            arriba,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(10), dp(10), dp(10), 0)
            }
        )

        // botones a la derecha: acercar, alejar, centrar
        botones = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lado = dp(56)
        fun lp() = LinearLayout.LayoutParams(lado, lado).apply { topMargin = dp(10) }
        botones.addView(botonRedondo("+") { mapView.model.mapViewPosition.zoomIn() }, lp())
        botones.addView(botonRedondo("−") { mapView.model.mapViewPosition.zoomOut() }, lp())
        botones.addView(botonRedondo("◎") { centrarEnMi() }, lp())
        botones.addView(botonRedondo("N") { rotacionAuto = false; fijarRotacion(0f) }, lp())
        botones.addView(botonRedondo("▲") { mostrarCursores() }, lp())
        raiz.addView(
            botones,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.BOTTOM).apply {
                setMargins(0, 0, dp(12), dp(36))
            }
        )

        // atribución obligatoria de OpenStreetMap
        raiz.addView(
            texto("© OpenStreetMap", 11f, 0xFF333333.toInt()).apply {
                setPadding(dp(6), dp(2), dp(6), dp(2))
                background = fondo(0xB3FFFFFF.toInt(), 6)
            },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.BOTTOM).apply {
                setMargins(dp(8), 0, 0, dp(8))
            }
        )

        // panel de abajo: sin mapa / descargando
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fondo(0xF20B3D5C.toInt(), 20)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            visibility = View.GONE
        }
        raiz.addView(
            panel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
                setMargins(dp(10), 0, dp(10), dp(10))
            }
        )

        // cartel de arriba durante la navegación: flecha, distancia e indicación
        bannerNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = fondo(0xF20B3D5C.toInt(), 16)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            visibility = View.GONE
        }
        flechaNav = texto("↑", 44f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            minWidth = dp(64)
        }
        distNav = texto("", 26f, Color.WHITE, true)
        textoNav = texto("", 17f, 0xFFCFE3F2.toInt())
        val columna = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        columna.addView(distNav)
        columna.addView(textoNav)
        bannerNav.addView(flechaNav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        bannerNav.addView(columna, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        velNav = chipVelocidad()
        bannerNav.addView(
            velNav,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
        )
        raiz.addView(
            bannerNav,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(10), dp(10), dp(10), 0)
            }
        )

        // panel de abajo para la ruta: vista previa y navegación
        panelRuta = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fondo(0xF20B3D5C.toInt(), 20)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            visibility = View.GONE
        }
        raiz.addView(
            panelRuta,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
                setMargins(dp(10), 0, dp(10), dp(32))
            }
        )

        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        setContentView(raiz)
    }

    private fun mostrarEstado(e: Estado) {
        estadoApp = e
        botones.visibility = if (e == Estado.LISTO) View.VISIBLE else View.GONE
        panel.removeAllViews()
        barra = null
        textoProgreso = null
        tituloBajada = null
        if (e != Estado.LISTO) {
            panelRuta.visibility = View.GONE
            acomodarBotones()
        }
        if (e == Estado.LISTO) {
            panel.visibility = View.GONE
            return
        }
        panel.visibility = View.VISIBLE
        val reg = Config.REGIONES.first()
        if (e == Estado.SIN_MAPA) {
            panel.addView(texto("Todavía no tenés ningún mapa", 20f, Color.WHITE, true))
            panel.addView(
                texto(
                    "Bajá el mapa con internet una sola vez. Después se usa sin conexión, incluso en modo avión.",
                    15f, 0xFFCFE3F2.toInt()
                ).apply { setPadding(0, dp(6), 0, dp(12)) }
            )
            mensajeError?.let {
                panel.addView(texto(it, 15f, 0xFFFFB4A8.toInt(), true).apply { setPadding(0, 0, 0, dp(12)) })
            }
            panel.addView(boton("Bajar ${reg.nombre}", true) { empezarDescarga(reg) })
            panel.addView(
                boton("Elegir un archivo .map del teléfono", false) { elegirArchivo() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
            )
        } else {
            val tb = texto("Bajando el mapa…", 20f, Color.WHITE, true)
            panel.addView(tb)
            tituloBajada = tb
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; isIndeterminate = true }
            panel.addView(pb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)).apply { topMargin = dp(12) })
            val tp = texto("Conectando…", 15f, 0xFFCFE3F2.toInt())
            panel.addView(tp, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
            panel.addView(
                boton("Cancelar", false) { bajada?.cancelar() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
            )
            barra = pb
            textoProgreso = tp
        }
    }

    // ------------------------------------------------------------------ mapas

    private fun abrirMapa(archivo: File): Boolean {
        return try {
            val datos = MapFile(archivo)
            quitarMapa()
            limpiarRuta()
            val cache = AndroidUtil.createTileCache(
                this, "tiles-" + archivo.nameWithoutExtension,
                mapView.model.displayModel.tileSize, 1f, mapView.model.frameBufferModel.overdrawFactor
            )
            val capa = TileRendererLayer(cache, datos, mapView.model.mapViewPosition, AndroidGraphicFactory.INSTANCE)
            capa.setXmlRenderTheme(InternalRenderTheme.DEFAULT)
            mapView.layerManager.layers.add(0, capa)
            tileCache = cache
            capaMapa = capa
            mapaActual = archivo
            getSharedPreferences("mapa", MODE_PRIVATE).edit().putString("actual", archivo.name).apply()

            val caja = datos.boundingBox()
            val yo = ubicacion
            if (yo != null && caja.contains(LatLong(yo.latitude, yo.longitude))) {
                mapView.setCenter(LatLong(yo.latitude, yo.longitude))
                mapView.setZoomLevel(16.toByte())
            } else {
                mapView.setCenter(caja.centerPoint)
                mapView.setZoomLevel(12.toByte())
            }
            mensajeError = null
            mostrarEstado(Estado.LISTO)
            ubicacion?.let { ponerMarcador(it) }
            cargarNav()
            true
        } catch (e: Throwable) {
            mensajeError = "No se pudo abrir el mapa: ${e.message ?: "archivo dañado"}."
            mostrarEstado(Estado.SIN_MAPA)
            false
        }
    }

    private fun quitarMapa() {
        capaMapa?.let {
            try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { }
            try { it.onDestroy() } catch (e: Exception) { }
        }
        capaMapa = null
        try { tileCache?.destroy() } catch (e: Exception) { }
        tileCache = null
        mapaActual = null
    }

    private fun empezarDescarga(region: Region) {
        if (bajada != null) return
        mensajeError = null
        mostrarEstado(Estado.BAJANDO)
        val d = Downloader(applicationContext, { hecho, total -> mostrarProgreso(hecho, total) }, { res, archivo -> terminarTarea(res, archivo) })
        d.alCambiarEtapa = { t -> tituloBajada?.text = t }
        bajada = d
        d.bajar(region)
    }

    private fun empezarDescargaRutas(region: Region) {
        if (bajada != null) return
        mensajeError = null
        bajandoRutas = true
        mostrarEstado(Estado.BAJANDO)
        val d = Downloader(applicationContext, { hecho, total -> mostrarProgreso(hecho, total) }, { res, archivo -> terminarTarea(res, archivo) })
        d.alCambiarEtapa = { t -> tituloBajada?.text = t }
        bajada = d
        d.bajarRutas(region)
    }

    private fun elegirArchivo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, PEDIDO_ARCHIVO)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PEDIDO_VOZ) {
            if (resultCode == RESULT_OK) {
                val dicho = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                if (!dicho.isNullOrBlank()) {
                    campo.setText(dicho)
                    campo.setSelection(campo.text.length)
                    buscar()
                }
            }
            return
        }
        if (requestCode != PEDIDO_ARCHIVO || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (bajada != null) return
        mensajeError = null
        mostrarEstado(Estado.BAJANDO)
        val d = Downloader(applicationContext, { hecho, total -> mostrarProgreso(hecho, total) }, { res, archivo -> terminarTarea(res, archivo) })
        bajada = d
        d.importar(uri)
    }

    private fun mostrarProgreso(hecho: Long, total: Long) {
        val pb = barra ?: return
        val tp = textoProgreso ?: return
        if (total > 0) {
            pb.isIndeterminate = false
            pb.progress = ((hecho * 1000) / total).toInt()
            tp.text = "${hecho / 1048576} de ${total / 1048576} MB"
        } else {
            tp.text = "${hecho / 1048576} MB"
        }
    }

    private fun terminarTarea(res: Resultado, archivo: File?) {
        bajada = null
        val soloRutas = bajandoRutas
        bajandoRutas = false
        when (res) {
            is Resultado.Ok, is Resultado.Parcial -> {
                if (soloRutas) {
                    mostrarEstado(if (mapaActual != null) Estado.LISTO else Estado.SIN_MAPA)
                    cargarNav()
                    Toast.makeText(this, "Rutas y buscador listos", Toast.LENGTH_SHORT).show()
                    return
                }
                val aviso = (res as? Resultado.Parcial)?.mensaje
                if (archivo != null && abrirMapa(archivo)) {
                    if (aviso != null) {
                        AlertDialog.Builder(this).setTitle("Mapa listo").setMessage(aviso).setPositiveButton("Entendido", null).show()
                    }
                    return
                }
                if (mapaActual == null) mostrarEstado(Estado.SIN_MAPA)
            }
            is Resultado.Cancelado -> {
                mensajeError = null
                mostrarEstado(if (mapaActual != null) Estado.LISTO else Estado.SIN_MAPA)
            }
            is Resultado.Error -> {
                mensajeError = res.mensaje
                mostrarEstado(if (mapaActual != null) Estado.LISTO else Estado.SIN_MAPA)
                if (mapaActual != null) {
                    estado.text = res.mensaje
                    AlertDialog.Builder(this).setTitle("No se pudo").setMessage(res.mensaje).setPositiveButton("Entendido", null).show()
                }
            }
        }
    }

    private fun mostrarMapas() {
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(4))
        }
        val lista = MapStore.installed(this)
        if (lista.isEmpty()) {
            caja.addView(texto("No hay mapas instalados.", 16f, 0xFF222222.toInt()))
        }
        var dialogo: AlertDialog? = null
        for (f in lista) {
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val activo = f == mapaActual
            fila.addView(texto(MapStore.niceName(f) + if (activo) "  (en uso)" else "", 16f, 0xFF0B3D5C.toInt(), true))
            fila.addView(texto(MapStore.sizeText(f), 13f, 0xFF555555.toInt()))
            val acciones = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (!activo) {
                acciones.addView(boton("Usar", true) { dialogo?.dismiss(); abrirMapa(f) })
            }
            acciones.addView(
                boton("Eliminar", false) {
                    dialogo?.dismiss()
                    confirmarBorrado(f)
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
            )
            fila.addView(acciones, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
            caja.addView(fila)
        }
        val mapaId = mapaActual?.nameWithoutExtension
        val regActual = Config.REGIONES.firstOrNull { it.id == mapaId }
        if (mapaId != null) {
            val hayNav = MapStore.navFile(this, mapaId).exists()
            caja.addView(texto("Rutas, buscador y colectivos", 16f, 0xFF0B3D5C.toInt(), true).apply { setPadding(0, dp(14), 0, 0) })
            caja.addView(
                texto(
                    if (navKit != null) "Listos: podés buscar direcciones y trazar rutas sin conexión." + (if (busRouter != null) " También cómo llegar en colectivo (botón 🚌 al elegir un destino)." else " Los colectivos todavía no están (bajalos con el botón de abajo).")
                    else if (hayNav) "Cargando…"
                    else if (regActual != null) "Todavía no los bajaste."
                    else "Este mapa no tiene datos de rutas.",
                    13f, 0xFF555555.toInt()
                )
            )
            if (regActual != null) {
                caja.addView(
                    boton(if (hayNav) "Actualizar rutas y buscador" else "Bajar rutas, buscador y colectivos", !hayNav) {
                        dialogo?.dismiss()
                        empezarDescargaRutas(regActual)
                    },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
                )
            }
        }
        val reg = Config.REGIONES.first()
        caja.addView(
            boton("Bajar o actualizar ${reg.nombre}", true) { dialogo?.dismiss(); empezarDescarga(reg) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
        )
        caja.addView(
            boton("Elegir un archivo .map", false) { dialogo?.dismiss(); elegirArchivo() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        )
        caja.addView(texto("Datos de mapa y rutas: © colaboradores de OpenStreetMap (licencia ODbL).", 12f, 0xFF555555.toInt()).apply { setPadding(0, dp(12), 0, 0) })
        val scroll = ScrollView(this).apply { addView(caja) }
        val d = AlertDialog.Builder(this).setTitle("Mapas sin conexión").setView(scroll).setNegativeButton("Cerrar", null).create()
        dialogo = d
        d.show()
    }

    private fun confirmarBorrado(f: File) {
        AlertDialog.Builder(this)
            .setTitle("¿Eliminar este mapa?")
            .setMessage("${MapStore.niceName(f)} (${MapStore.sizeText(f)}). Para volver a usarlo hay que bajarlo de nuevo.")
            .setPositiveButton("Eliminar") { _, _ ->
                val eraElActual = f == mapaActual
                if (eraElActual) { quitarMapa(); limpiarRuta(); navKit = null }
                f.delete()
                MapStore.navFile(this, f.nameWithoutExtension).delete()
                MapStore.busFile(this, f.nameWithoutExtension).delete()
                busRouter = null
                if (eraElActual) {
                    val otro = MapStore.installed(this).firstOrNull()
                    if (otro != null) abrirMapa(otro) else mostrarEstado(Estado.SIN_MAPA)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ------------------------------------------------------------------ GPS

    private fun tienePermiso(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun pedirPermisoYEmpezar() {
        if (tienePermiso()) {
            empezarGps()
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), PEDIDO_UBICACION)
            actualizarEstadoGps()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PEDIDO_UBICACION) {
            if (tienePermiso()) empezarGps() else actualizarEstadoGps()
        }
    }

    private fun empezarGps() {
        if (gpsActivo || !tienePermiso()) return
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, oyente)
                gpsActivo = true
            }
            val ultima = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (ultima != null && ubicacion == null) alRecibirUbicacion(ultima, false)
        } catch (e: SecurityException) {
            // sin permiso: se avisa en la barra de estado
        }
        actualizarEstadoGps()
    }

    private fun detenerGps() {
        try { lm.removeUpdates(oyente) } catch (e: Exception) { }
        gpsActivo = false
    }

    private fun alRecibirUbicacion(l: Location, fresca: Boolean = true) {
        ubicacion = l
        if (fresca) ultimaFijacion = System.currentTimeMillis()
        ponerMarcador(l)
        if (navegando) avanzarNavegacion(l)
        if (seguir && capaMapa != null) centrarSeguimiento(l)
        actualizarEstadoGps()
    }

    private fun fijarRotacion(grados: Float) {
        var g = grados
        while (g > 180f) g -= 360f
        while (g < -180f) g += 360f
        rotacionMapa = g
        mapView.rotation = g
    }

    private fun anguloEntreDedos(ev: MotionEvent): Float =
        Math.toDegrees(Math.atan2((ev.getY(1) - ev.getY(0)).toDouble(), (ev.getX(1) - ev.getX(0)).toDouble())).toFloat()

    /** Girar el mapa con dos dedos. Se mide sobre el contenedor, que no gira, para que no se descontrole. */
    private fun girarConDedos(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> if (ev.pointerCount == 2) anguloDedos = anguloEntreDedos(ev)
            MotionEvent.ACTION_MOVE -> if (ev.pointerCount == 2 && !anguloDedos.isNaN()) {
                val a = anguloEntreDedos(ev)
                var d = a - anguloDedos
                if (d > 180f) d -= 360f
                if (d < -180f) d += 360f
                if (Math.abs(d) >= 0.4f) {
                    anguloDedos = a
                    rotacionAuto = false
                    fijarRotacion(rotacionMapa + d)
                }
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> anguloDedos = Float.NaN
        }
    }

    /** Borra el tramo de la ruta que ya recorriste: la línea empieza en vos y sigue hacia adelante. */
    private fun recortarRuta(l: Location, segmento: Int) {
        val r = ruta ?: return
        val linea = capaRuta ?: return
        synchronized(linea) {
            val pts = linea.latLongs
            pts.clear()
            pts.add(LatLong(l.latitude, l.longitude))
            var i = Math.max(0, segmento + 1)
            while (i < r.puntos()) {
                pts.add(LatLong(r.lat[i], r.lon[i]))
                i++
            }
        }
        linea.requestRedraw()
    }

    /** Centra el mapa en vos; en navegación lo corre hacia adelante para ver más camino (la moto queda en el tercio de abajo). */
    private fun centrarSeguimiento(l: Location) {
        var lat = l.latitude
        var lon = l.longitude
        if (navegando && !rumboRuta.isNaN() && contenedorMapa.height > 0) {
            val z = mapView.model.mapViewPosition.zoomLevel.toInt()
            val tile = mapView.model.displayModel.tileSize.toDouble()
            val metrosPorPixel = 40075016.686 * Math.cos(Math.toRadians(lat)) / (tile * Math.pow(2.0, z.toDouble()))
            val d = metrosPorPixel * contenedorMapa.height * 0.2
            val b = Math.toRadians(rumboRuta.toDouble())
            lat += d * Math.cos(b) / 111320.0
            lon += d * Math.sin(b) / (111320.0 * Math.cos(Math.toRadians(l.latitude)))
        }
        mapView.setCenter(LatLong(lat, lon))
    }

    /** Se acerca cuando falta poco para la maniobra y se aleja después, para ver el trayecto. */
    private fun zoomAutomatico(falta: Double, velocidadMs: Float) {
        val ahora = System.currentTimeMillis()
        if (!seguir || ahora < pausaZoomHasta || ahora - ultimoCambioZoom < 2500L) return
        var objetivo = if (falta < 150.0) 18 else if (falta < 400.0) 17 else 16
        if (velocidadMs > 19f && objetivo > 15) objetivo -= 1
        val actual = mapView.model.mapViewPosition.zoomLevel.toInt()
        if (actual != objetivo) {
            mapView.model.mapViewPosition.setZoomLevel(objetivo.toByte(), true)
            ultimoCambioZoom = ahora
        }
    }

    private fun ponerMarcador(l: Location) {
        if (capaMapa == null) return
        if (navegando && !rumboRuta.isNaN()) rumboCursor = rumboRuta
        else if (l.hasBearing() && l.hasSpeed() && l.speed > 1f) rumboCursor = l.bearing
        val pos = LatLong(l.latitude, l.longitude)
        val m = marcador
        val cambio = estiloDibujado != cursorEstilo ||
            (cursorEstilo != 0 && diferenciaAngulo(rumboCursor, rumboDibujado) >= 8f)
        if (m == null || cambio) {
            if (m != null) {
                try { mapView.layerManager.layers.remove(m) } catch (e: Exception) { }
            }
            val nuevo = Marker(pos, cursorBitmap(), 0, 0)
            mapView.layerManager.layers.add(nuevo)
            marcador = nuevo
            estiloDibujado = cursorEstilo
            rumboDibujado = rumboCursor
        } else {
            m.latLong = pos
            m.requestRedraw()
        }
    }

    private fun diferenciaAngulo(a: Float, b: Float): Float {
        var d = Math.abs(a - b) % 360f
        if (d > 180f) d = 360f - d
        return d
    }

    private fun cursorBitmap(): org.mapsforge.core.graphics.Bitmap =
        AndroidGraphicFactory.convertToBitmap(BitmapDrawable(resources, dibujarCursor(cursorEstilo, rumboCursor, dp(48))))

    /** Dibuja el cursor visto desde arriba, apuntando hacia "rumbo" grados (0 = norte). */
    private fun dibujarCursor(estilo: Int, rumbo: Float, tam: Int): android.graphics.Bitmap {
        val bmp = android.graphics.Bitmap.createBitmap(tam, tam, android.graphics.Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val azul = 0xFF1976D2.toInt()
        val oscuro = 0xFF14283A.toInt()
        val relleno = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = azul }
        val borde = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 0.09f; strokeJoin = Paint.Join.ROUND }
        val negro = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = oscuro }
        val cx = tam / 2f
        val cy = tam / 2f
        if (estilo == 0) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Color.WHITE
            c.drawCircle(cx, cy, tam * 0.30f, p)
            p.color = azul
            c.drawCircle(cx, cy, tam * 0.22f, p)
            return bmp
        }
        val u = tam * 0.7f
        c.save()
        c.translate(cx, cy)
        c.rotate(rumbo)
        c.scale(u, u)
        fun caja(x1: Float, y1: Float, x2: Float, y2: Float, radio: Float, color: Int, conBorde: Boolean) {
            val r = RectF(x1, y1, x2, y2)
            if (conBorde) c.drawRoundRect(r, radio, radio, borde)
            val pr = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = color }
            c.drawRoundRect(r, radio, radio, pr)
        }
        when (estilo) {
            1 -> {
                val f = Path().apply {
                    moveTo(0f, -0.5f); lineTo(0.38f, 0.46f); lineTo(0f, 0.22f); lineTo(-0.38f, 0.46f); close()
                }
                c.drawPath(f, borde)
                c.drawPath(f, relleno)
            }
            2 -> {
                caja(-0.06f, -0.5f, 0.06f, -0.2f, 0.05f, oscuro, false)
                caja(-0.07f, 0.18f, 0.07f, 0.5f, 0.05f, oscuro, false)
                caja(-0.09f, -0.32f, 0.09f, 0.3f, 0.08f, azul, true)
                val manubrioB = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 0.13f; strokeCap = Paint.Cap.ROUND }
                val manubrio = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = oscuro; strokeWidth = 0.07f; strokeCap = Paint.Cap.ROUND }
                c.drawLine(-0.34f, -0.26f, 0.34f, -0.26f, manubrioB)
                c.drawLine(-0.34f, -0.26f, 0.34f, -0.26f, manubrio)
                caja(-0.2f, -0.2f, 0.2f, 0.06f, 0.1f, 0xFF64B5F6.toInt(), true)
                val casco = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFFFFC107.toInt() }
                c.drawCircle(0f, -0.04f, 0.11f, casco)
            }
            3 -> {
                caja(-0.28f, -0.34f, -0.19f, -0.13f, 0.03f, oscuro, false)
                caja(0.19f, -0.34f, 0.28f, -0.13f, 0.03f, oscuro, false)
                caja(-0.28f, 0.15f, -0.19f, 0.36f, 0.03f, oscuro, false)
                caja(0.19f, 0.15f, 0.28f, 0.36f, 0.03f, oscuro, false)
                caja(-0.22f, -0.47f, 0.22f, 0.47f, 0.13f, azul, true)
                caja(-0.16f, -0.24f, 0.16f, -0.07f, 0.04f, 0xFFB3E5FC.toInt(), false)
                caja(-0.16f, -0.04f, 0.16f, 0.17f, 0.04f, 0xFF0D47A1.toInt(), false)
                caja(-0.15f, 0.2f, 0.15f, 0.31f, 0.04f, 0xFFB3E5FC.toInt(), false)
            }
            else -> {
                caja(-0.28f, -0.38f, -0.19f, -0.17f, 0.03f, oscuro, false)
                caja(0.19f, -0.38f, 0.28f, -0.17f, 0.03f, oscuro, false)
                caja(-0.28f, 0.2f, -0.19f, 0.41f, 0.03f, oscuro, false)
                caja(0.19f, 0.2f, 0.28f, 0.41f, 0.03f, oscuro, false)
                caja(-0.22f, -0.5f, 0.22f, 0.5f, 0.08f, azul, true)
                caja(-0.18f, -0.43f, 0.18f, -0.04f, 0.05f, 0xFF0D47A1.toInt(), false)
                caja(-0.14f, -0.38f, 0.14f, -0.24f, 0.03f, 0xFFB3E5FC.toInt(), false)
                caja(-0.17f, 0.02f, 0.17f, 0.45f, 0.03f, 0xFF455A64.toInt(), false)
            }
        }
        c.restore()
        return bmp
    }

    private fun mostrarCursores() {
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(4))
        }
        var dialogo: AlertDialog? = null
        estilos.forEachIndexed { i, nombre ->
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = fondo(if (i == cursorEstilo) 0xFFD6E6F3.toInt() else Color.TRANSPARENT, 12)
            }
            val img = ImageView(this).apply {
                setImageBitmap(dibujarCursor(i, 0f, dp(56)))
                background = fondo(0xFF8FA3B3.toInt(), 12)
            }
            fila.addView(img, LinearLayout.LayoutParams(dp(56), dp(56)))
            fila.addView(
                texto(nombre + if (i == cursorEstilo) "  ✓" else "", 18f, 0xFF0B3D5C.toInt(), true).apply { setPadding(dp(14), 0, 0, 0) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            fila.setOnClickListener {
                elegirCursor(i)
                dialogo?.dismiss()
            }
            caja.addView(fila, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })
        }
        val scroll = ScrollView(this).apply { addView(caja) }
        val d = AlertDialog.Builder(this).setTitle("Elegí tu cursor").setView(scroll).setNegativeButton("Cerrar", null).create()
        dialogo = d
        d.show()
    }

    private fun elegirCursor(i: Int) {
        cursorEstilo = i
        getSharedPreferences("mapa", MODE_PRIVATE).edit().putInt("cursor", i).apply()
        ubicacion?.let { ponerMarcador(it) }
    }

    private fun centrarEnMi() {
        val l = ubicacion
        if (l == null) {
            estado.text = "Todavía no hay ubicación. Salí a un lugar abierto."
            return
        }
        seguir = true
        if (navegando) rotacionAuto = true
        mapView.setCenter(LatLong(l.latitude, l.longitude))
        if (mapView.model.mapViewPosition.zoomLevel < 15) mapView.setZoomLevel(16.toByte())
    }

    private fun rumbo(grados: Float): String {
        val n = arrayOf("N", "NE", "E", "SE", "S", "SO", "O", "NO")
        return n[(((grados + 22.5f) % 360f) / 45f).toInt().coerceIn(0, 7)]
    }

    private fun actualizarEstadoGps() {
        if (bajada != null) return
        if (!tienePermiso()) {
            estado.text = "Falta el permiso de ubicación"
            return
        }
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            estado.text = "El GPS está apagado. Activalo en los ajustes."
            return
        }
        if (!gpsActivo) empezarGps()
        val l = ubicacion
        val hace = System.currentTimeMillis() - ultimaFijacion
        if (l == null || ultimaFijacion == 0L) {
            estado.text = "Buscando señal GPS…"
        } else if (hace > 8000) {
            estado.text = "Señal GPS perdida, buscando…"
        } else {
            var t = "GPS ±${l.accuracy.toInt()} m"
            if (l.hasSpeed()) t += " · ${(l.speed * 3.6f).toInt()} km/h"
            if (l.hasBearing() && l.hasSpeed() && l.speed > 1f) t += " · ${rumbo(l.bearing)}"
            estado.text = t
        }
    }

    // ------------------------------------------------------------------ rutas y buscador

    private fun referencia(): LatLong {
        val l = ubicacion
        if (l != null) return LatLong(l.latitude, l.longitude)
        return mapView.model.mapViewPosition.center
    }

    /** Carga en segundo plano las calles y el buscador del mapa en uso. */
    private fun cargarNav() {
        navKit = null
        val mapa = mapaActual
        if (mapa == null) {
            actualizarAvisoBuscador()
            return
        }
        cargarBus(mapa)
        val f = MapStore.navFile(this, mapa.nameWithoutExtension)
        if (!f.exists() || cargandoNav) {
            actualizarAvisoBuscador()
            return
        }
        cargandoNav = true
        actualizarAvisoBuscador()
        Thread {
            var kit: NavKit? = null
            var error = ""
            try {
                val datos = NavData.cargar(f)
                kit = NavKit(datos, Router(datos), Searcher(datos))
            } catch (e: Throwable) {
                error = e.message ?: "error"
            }
            main.post {
                cargandoNav = false
                navKit = kit
                if (kit == null) {
                    Toast.makeText(this, "No se pudieron cargar las rutas: $error", Toast.LENGTH_LONG).show()
                }
                actualizarAvisoBuscador()
            }
        }.start()
    }

    /** Carga en segundo plano las líneas de colectivo, si ya se bajaron. */
    private fun cargarBus(mapa: File) {
        busRouter = null
        val fb = MapStore.busFile(this, mapa.nameWithoutExtension)
        if (!fb.exists()) return
        Thread {
            var br: BusRouter? = null
            try {
                br = BusRouter(BusData.cargar(fb))
            } catch (e: Throwable) {
            }
            main.post { if (mapaActual == mapa) busRouter = br }
        }.start()
    }

    private fun actualizarAvisoBuscador() {
        campo.hint = when {
            navKit != null -> "Buscar dirección o lugar"
            cargandoNav -> "Cargando el buscador…"
            else -> "Buscar (primero hay que bajar las rutas)"
        }
    }

    private fun ocultarTeclado() {
        try {
            val im = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            im.hideSoftInputFromWindow(campo.windowToken, 0)
            campo.clearFocus()
        } catch (e: Exception) {
        }
    }

    private fun ofrecerBajarRutas() {
        val id = mapaActual?.nameWithoutExtension
        val reg = Config.REGIONES.firstOrNull { it.id == id }
        if (reg == null) {
            AlertDialog.Builder(this)
                .setTitle("Sin rutas para este mapa")
                .setMessage("Este mapa no tiene datos de rutas y buscador. Usá el mapa de Buenos Aires desde el botón Mapas.")
                .setPositiveButton("Entendido", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Rutas y buscador")
            .setMessage("Para buscar direcciones y trazar rutas sin conexión hay que bajar los datos de las calles. Se bajan una sola vez, con internet.")
            .setPositiveButton("Bajar ahora") { _, _ -> empezarDescargaRutas(reg) }
            .setNegativeButton("Ahora no", null)
            .show()
    }

    // ------------------------------------------------------------------ búsqueda

    private fun buscar() {
        val q = campo.text.toString().trim()
        if (q.isEmpty()) return
        ocultarTeclado()
        if (capaMapa == null) {
            Toast.makeText(this, "Primero hace falta un mapa.", Toast.LENGTH_SHORT).show()
            return
        }
        val kit = navKit
        if (kit == null) {
            if (cargandoNav) {
                Toast.makeText(this, "Cargando el buscador, probá en unos segundos.", Toast.LENGTH_SHORT).show()
            } else {
                ofrecerBajarRutas()
            }
            return
        }
        mostrarResultadosTexto("Buscando…")
        val ref = referencia()
        Thread {
            val res: List<Searcher.Lugar> = try {
                kit.buscador.buscar(q, 80, ref.latitude, ref.longitude)
            } catch (e: Throwable) {
                emptyList()
            }
            main.post { mostrarResultados(res) }
        }.start()
    }

    private fun mostrarResultadosTexto(t: String) {
        listaResultados.removeAllViews()
        listaResultados.addView(texto(t, 15f, 0xFFCFE3F2.toInt()).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) })
        scrollResultados.visibility = View.VISIBLE
    }

    private fun mostrarResultados(todos: List<Searcher.Lugar>) {
        quitarPines()
        val lugares = todos.filter { it.tipo == Searcher.LUGAR }.sortedBy { it.distancia }
        if (lugares.size >= 2) {
            mostrarPines(lugares)
            return
        }
        val res = todos.take(12)
        if (res.isEmpty()) {
            mostrarResultadosTexto("No encontré nada. Probá con otra escritura, por ejemplo \"Rivadavia 7000\" o \"Medrano y Rivadavia\".")
            return
        }
        listaResultados.removeAllViews()
        for (l in res) {
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = fondo(0x26FFFFFF, 10)
            }
            fila.addView(texto(l.titulo, 16f, Color.WHITE, true))
            fila.addView(texto(l.detalle + " · " + Formato.distancia(l.distancia), 13f, 0xFFCFE3F2.toInt()))
            fila.setOnClickListener { elegirDestino(l.titulo, l.lat, l.lon) }
            listaResultados.addView(
                fila,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) }
            )
        }
        scrollResultados.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------------ pines de la búsqueda

    private fun mostrarPines(lugares: List<Searcher.Lugar>) {
        val usados = lugares.take(40)
        lugaresPines = usados
        val bmp = dibujarPin(0xFFEF6C00.toInt())
        val icono = AndroidGraphicFactory.convertToBitmap(BitmapDrawable(resources, bmp))
        for (l in usados) {
            val lugar = l
            val m = object : Marker(LatLong(lugar.lat, lugar.lon), icono, 0, -bmp.height / 2) {
                override fun onTap(tapLatLong: LatLong, layerXY: Point, tapXY: Point): Boolean {
                    if (contains(layerXY, tapXY)) {
                        main.post { preguntarIr(lugar) }
                        return true
                    }
                    return false
                }
            }
            mapView.layerManager.layers.add(m)
            pines.add(m)
        }
        refrescarCursorArriba()
        ajustarVista(usados)
        val extra = if (lugares.size > usados.size) " (los 40 más cercanos)" else ""
        textoPines.text = "${usados.size} lugares$extra · tocá un pin"
        barraPines.visibility = View.VISIBLE
        scrollResultados.visibility = View.GONE
    }

    private fun preguntarIr(l: Searcher.Lugar) {
        android.app.AlertDialog.Builder(this)
            .setTitle(l.titulo)
            .setMessage(l.detalle + " · a " + Formato.distancia(l.distancia))
            .setPositiveButton("Ir") { _, _ -> elegirDestino(l.titulo, l.lat, l.lon) }
            .setNeutralButton("⭐ Guardar") { _, _ -> guardarComo(l.titulo, l.detalle, l.lat, l.lon) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun alternarListaPines() {
        if (scrollResultados.visibility == View.VISIBLE) {
            scrollResultados.visibility = View.GONE
            return
        }
        listaResultados.removeAllViews()
        for (l in lugaresPines) {
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = fondo(0x26FFFFFF, 10)
            }
            fila.addView(texto(l.titulo, 16f, Color.WHITE, true))
            fila.addView(texto(l.detalle + " · " + Formato.distancia(l.distancia), 13f, 0xFFCFE3F2.toInt()))
            fila.setOnClickListener { elegirDestino(l.titulo, l.lat, l.lon) }
            listaResultados.addView(
                fila,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) }
            )
        }
        scrollResultados.visibility = View.VISIBLE
    }

    private fun quitarPines() {
        for (m in pines) {
            try { mapView.layerManager.layers.remove(m) } catch (e: Exception) { }
        }
        pines.clear()
        lugaresPines = emptyList()
        barraPines.visibility = View.GONE
    }

    /** Centra y aleja el mapa lo justo para que entren todos los pines. */
    private fun ajustarVista(lugares: List<Searcher.Lugar>) {
        var minLat = lugares[0].lat
        var maxLat = minLat
        var minLon = lugares[0].lon
        var maxLon = minLon
        for (l in lugares) {
            if (l.lat < minLat) minLat = l.lat
            if (l.lat > maxLat) maxLat = l.lat
            if (l.lon < minLon) minLon = l.lon
            if (l.lon > maxLon) maxLon = l.lon
        }
        val spanLat = (maxLat - minLat) * 1.3 + 0.0006
        val spanLon = (maxLon - minLon) * 1.3 + 0.0006
        val cLat = (minLat + maxLat) / 2
        val cLon = (minLon + maxLon) / 2
        rotacionAuto = false
        fijarRotacion(0f)
        val ancho = contenedorMapa.width.toDouble()
        val alto = contenedorMapa.height.toDouble()
        val tile = mapView.model.displayModel.tileSize.toDouble()
        var z = 13
        if (ancho > 0 && alto > 0) {
            val cosLat = Math.cos(Math.toRadians(cLat))
            z = 8
            for (cand in 17 downTo 8) {
                val mundo = tile * Math.pow(2.0, cand.toDouble())
                val pw = spanLon / 360.0 * mundo
                val ph = spanLat / 360.0 * mundo / cosLat
                if (pw <= ancho * 0.9 && ph <= alto * 0.5) {
                    z = cand
                    break
                }
            }
        }
        seguir = false
        mapView.setCenter(LatLong(cLat, cLon))
        mapView.setZoomLevel(z.toByte())
    }

    private fun ocultarResultados() {
        scrollResultados.visibility = View.GONE
    }

    // ------------------------------------------------------------------ destino y ruta

    /** Toque largo sobre el mapa: ese punto pasa a ser el destino. */
    private fun alMantener(x: Float, y: Float) {
        if (capaMapa == null || navegando) return
        val p = mapView.mapViewProjection.fromPixels(x.toDouble(), y.toDouble()) ?: return
        val kit = navKit
        if (kit == null) {
            if (!cargandoNav) ofrecerBajarRutas()
            return
        }
        var nombre = "Punto elegido en el mapa"
        try {
            val s = kit.datos.ubicar(p.latitude, p.longitude, 60.0)
            if (s != null) {
                val n = kit.datos.lName[s.tramo]
                if (n >= 0) nombre = "Cerca de " + kit.datos.names[n]
            }
        } catch (e: Throwable) {
        }
        elegirDestino(nombre, p.latitude, p.longitude)
    }


    // ---------------------------------------------------------------- Opciones de ruta

    private var opRuta = Router.Opciones()

    private fun opcionesRuta(): Router.Opciones {
        val pr = getSharedPreferences("mapa", MODE_PRIVATE)
        val o = Router.Opciones()
        o.aPie = pr.getBoolean("pie", false)
        o.evitarAutopistas = pr.getBoolean("ev_auto", false)
        o.evitarPeajes = pr.getBoolean("ev_peaje", false)
        o.evitarCrucesTren = pr.getBoolean("ev_tren", false)
        return o
    }

    private fun navTieneDatosExtra(): Boolean {
        val d = navKit?.datos ?: return true
        val f = d.lFlags
        for (i in f.indices) if ((f[i] and 384) != 0) return true
        return false
    }

    private fun abrirOpcionesRuta() {
        val pr = getSharedPreferences("mapa", MODE_PRIVATE)
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }
        val grupo = android.widget.RadioGroup(this)
        val rVeh = android.widget.RadioButton(this).apply { text = "🏍 Moto / auto"; id = 101; textSize = 17f }
        val rPie = android.widget.RadioButton(this).apply { text = "🚶 A pie (ignora el sentido de las calles)"; id = 102; textSize = 17f }
        grupo.addView(rVeh)
        grupo.addView(rPie)
        grupo.check(if (pr.getBoolean("pie", false)) 102 else 101)
        caja.addView(grupo)
        caja.addView(texto("En moto / auto, evitar:", 15f, 0xFF0B3D5C.toInt(), true).apply { setPadding(0, dp(14), 0, dp(2)) })
        val cA = android.widget.CheckBox(this).apply { text = "Autopistas"; textSize = 17f; isChecked = pr.getBoolean("ev_auto", false) }
        val cP = android.widget.CheckBox(this).apply { text = "Peajes"; textSize = 17f; isChecked = pr.getBoolean("ev_peaje", false) }
        val cT = android.widget.CheckBox(this).apply { text = "Cruces de tren (pasos a nivel)"; textSize = 17f; isChecked = pr.getBoolean("ev_tren", false) }
        caja.addView(cA)
        caja.addView(cP)
        caja.addView(cT)
        if (navKit != null && !navTieneDatosExtra()) {
            caja.addView(
                texto("Peajes y cruces de tren necesitan el archivo de rutas nuevo: Mapas → \"Actualizar rutas y buscador\". Hasta entonces esas dos opciones no hacen nada.", 13f, 0xFFB26A00.toInt())
                    .apply { setPadding(0, dp(10), 0, 0) }
            )
        }
        caja.addView(
            texto("Si no hay otro camino, la ruta pasa igual y te avisa.", 13f, 0xFF555555.toInt()).apply { setPadding(0, dp(8), 0, 0) }
        )
        AlertDialog.Builder(this)
            .setTitle("Opciones de ruta")
            .setView(ScrollView(this).apply { addView(caja) })
            .setPositiveButton("Aplicar") { _, _ ->
                pr.edit()
                    .putBoolean("pie", grupo.checkedRadioButtonId == 102)
                    .putBoolean("ev_auto", cA.isChecked)
                    .putBoolean("ev_peaje", cP.isChecked)
                    .putBoolean("ev_tren", cT.isChecked)
                    .apply()
                if (hayDestino && !navegando && ubicacion != null) calcularRuta(false)
                else if (hayDestino && navegando) calcularRuta(true)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------------------------------------------------------- Mis lugares

    private class MiLugar(var id: Long, var nombre: String, var direccion: String, var lat: Double, var lon: Double, var tipo: Int)

    private val TIPO_NORMAL = 0
    private val TIPO_CASA = 1
    private val TIPO_TRABAJO = 2
    private val MAX_LUGARES = 50

    private fun leerLugares(): MutableList<MiLugar> {
        val res = ArrayList<MiLugar>()
        try {
            val txt = getSharedPreferences("mapa", MODE_PRIVATE).getString("lugares", null) ?: return res
            val arr = org.json.JSONArray(txt)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                res.add(MiLugar(o.getLong("id"), o.getString("n"), o.optString("d", ""), o.getDouble("la"), o.getDouble("lo"), o.getInt("t")))
            }
        } catch (e: Throwable) {
        }
        return res
    }

    private fun guardarLugares(l: List<MiLugar>) {
        val arr = org.json.JSONArray()
        for (p in l) {
            arr.put(
                org.json.JSONObject().put("id", p.id).put("n", p.nombre).put("d", p.direccion)
                    .put("la", p.lat).put("lo", p.lon).put("t", p.tipo)
            )
        }
        getSharedPreferences("mapa", MODE_PRIVATE).edit().putString("lugares", arr.toString()).apply()
    }

    private var dialogoLugares: AlertDialog? = null
    private var cajaLugares: LinearLayout? = null

    private fun abrirMisLugares() {
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(4))
        }
        cajaLugares = caja
        refrescarLugares()
        dialogoLugares = AlertDialog.Builder(this)
            .setTitle("⭐ Mis lugares")
            .setView(ScrollView(this).apply { addView(caja) })
            .setPositiveButton("Cerrar", null)
            .show()
    }

    private fun refrescarLugares() {
        val caja = cajaLugares ?: return
        caja.removeAllViews()
        val todos = leerLugares()
        val casa = todos.firstOrNull { it.tipo == TIPO_CASA }
        val trabajo = todos.firstOrNull { it.tipo == TIPO_TRABAJO }
        val otros = todos.filter { it.tipo == TIPO_NORMAL }
        caja.addView(tituloSeccion("Casa"))
        caja.addView(filaLugar(casa, "🏠", "Casa", TIPO_CASA))
        caja.addView(tituloSeccion("Trabajo"))
        caja.addView(filaLugar(trabajo, "💼", "Trabajo", TIPO_TRABAJO))
        caja.addView(tituloSeccion("Otros lugares (${otros.size}/$MAX_LUGARES)"))
        if (otros.isEmpty()) {
            caja.addView(texto("Todavía no guardaste ninguno.", 15f, 0xFF777777.toInt()).apply { setPadding(dp(8), dp(4), 0, dp(4)) })
        }
        for (o in otros) caja.addView(filaLugar(o, "📍", o.nombre, TIPO_NORMAL))
        caja.addView(boton("＋ Agregar lugar", false) {
            if (otros.size >= MAX_LUGARES) {
                Toast.makeText(this, "Llegaste al máximo de $MAX_LUGARES lugares.", Toast.LENGTH_SHORT).show()
            } else {
                editarLugar(null, TIPO_NORMAL)
            }
        }.apply { (this).layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) } })
    }

    private fun tituloSeccion(t: String): TextView =
        texto(t, 14f, 0xFF1976D2.toInt(), true).apply { setPadding(dp(4), dp(12), 0, dp(2)) }

    private fun filaLugar(p: MiLugar?, icono: String, etiqueta: String, tipo: Int): View {
        val fila = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (p == null) {
            col.addView(texto("$icono $etiqueta", 17f, 0xFF222222.toInt(), true))
            col.addView(texto("Sin guardar · tocá ✏ para cargarla", 13f, 0xFF777777.toInt()))
        } else {
            col.addView(texto("$icono ${if (tipo == TIPO_NORMAL) p.nombre else etiqueta}", 17f, 0xFF222222.toInt(), true))
            val sub = if (tipo == TIPO_NORMAL) p.direccion else (if (p.direccion.isNotEmpty()) p.direccion else p.nombre)
            if (sub.isNotEmpty()) col.addView(texto(sub, 13f, 0xFF555555.toInt()))
            col.setOnClickListener {
                dialogoLugares?.dismiss()
                elegirDestino(p.nombre, p.lat, p.lon)
            }
        }
        fila.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fila.addView(iconoAccion("✏") { editarLugar(p, tipo) })
        if (p != null) {
            fila.addView(iconoAccion("✕") {
                AlertDialog.Builder(this)
                    .setTitle("¿Lo borro?")
                    .setMessage(if (tipo == TIPO_NORMAL) p.nombre else etiqueta)
                    .setPositiveButton("Sí") { _, _ ->
                        val l = leerLugares()
                        l.removeAll { it.id == p.id }
                        guardarLugares(l)
                        refrescarLugares()
                    }
                    .setNegativeButton("No", null)
                    .show()
            })
        }
        return fila
    }

    private fun iconoAccion(t: String, accion: () -> Unit): TextView =
        TextView(this).apply {
            text = t
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(0xFF0B3D5C.toInt())
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener { accion() }
        }

    /** Alta o edición de un lugar: nombre (solo en la lista) y dirección buscada en el buscador sin conexión. */
    private fun editarLugar(actual: MiLugar?, tipo: Int) {
        val kit = navKit
        if (kit == null) {
            Toast.makeText(this, "Hace falta el buscador de rutas (Mapas → Rutas y buscador).", Toast.LENGTH_LONG).show()
            return
        }
        var lat = actual?.lat ?: 0.0
        var lon = actual?.lon ?: 0.0
        var dir = actual?.direccion ?: ""
        var elegido = actual != null
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(4))
        }
        val campoNombre = EditText(this).apply { hint = "Nombre (ej: Casa de Juan)"; setText(actual?.nombre ?: ""); setSingleLine() }
        if (tipo == TIPO_NORMAL) caja.addView(campoNombre)
        val campoDir = EditText(this).apply { hint = "Calle y número"; setText(dir); setSingleLine() }
        caja.addView(campoDir)
        val estado = texto(if (elegido) "Dirección actual guardada." else "Buscá la dirección y elegí una de la lista.", 13f, 0xFF555555.toInt())
            .apply { setPadding(0, dp(4), 0, dp(4)) }
        val lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val buscarBtn = boton("Buscar dirección", false) {
            val q = campoDir.text.toString().trim()
            if (q.isNotEmpty()) {
                ocultarTecladoDe(campoDir)
                estado.text = "Buscando…"
                lista.removeAllViews()
                val ref = referencia()
                Thread {
                    val res: List<Searcher.Lugar> = try {
                        kit.buscador.buscar(q, 8, ref.latitude, ref.longitude)
                    } catch (e: Throwable) {
                        emptyList()
                    }
                    main.post {
                        estado.text = if (res.isEmpty()) "No encontré esa dirección." else "Tocá la correcta:"
                        for (r in res) {
                            lista.addView(texto("${r.titulo}\n${r.detalle}", 14f, 0xFF222222.toInt()).apply {
                                setPadding(dp(8), dp(8), dp(8), dp(8))
                                background = fondo(0xFFE3EEF7.toInt(), 10)
                                (this as View).layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) }
                                setOnClickListener {
                                    lat = r.lat; lon = r.lon
                                    dir = r.titulo + (if (r.detalle.isNotEmpty()) ", " + r.detalle else "")
                                    elegido = true
                                    campoDir.setText(r.titulo)
                                    estado.text = "✔ Elegida: ${r.titulo}"
                                    lista.removeAllViews()
                                }
                            })
                        }
                    }
                }.start()
            }
        }
        caja.addView(buscarBtn)
        caja.addView(estado)
        caja.addView(lista)
        val titulo = when (tipo) {
            TIPO_CASA -> "Casa"
            TIPO_TRABAJO -> "Trabajo"
            else -> if (actual == null) "Nuevo lugar" else "Editar lugar"
        }
        val d = AlertDialog.Builder(this)
            .setTitle(titulo)
            .setView(ScrollView(this).apply { addView(caja) })
            .setPositiveButton("Guardar", null)
            .setNegativeButton("Cancelar", null)
            .create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val nombre = if (tipo == TIPO_NORMAL) campoNombre.text.toString().trim() else titulo
            if (!elegido) {
                Toast.makeText(this, "Buscá la dirección y elegila de la lista.", Toast.LENGTH_SHORT).show()
            } else if (nombre.isEmpty()) {
                Toast.makeText(this, "Ponele un nombre.", Toast.LENGTH_SHORT).show()
            } else {
                val l = leerLugares()
                if (actual != null) l.removeAll { it.id == actual.id }
                if (tipo != TIPO_NORMAL) l.removeAll { it.tipo == tipo }
                l.add(MiLugar(actual?.id ?: System.currentTimeMillis(), nombre, dir, lat, lon, tipo))
                guardarLugares(l)
                d.dismiss()
                refrescarLugares()
            }
        }
    }

    private fun ocultarTecladoDe(v: View) {
        try {
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
        } catch (e: Throwable) {
        }
    }

    /** Guarda un punto (resultado de búsqueda, pin, vista previa) como Casa, Trabajo u otro lugar. */
    private fun guardarComo(titulo: String, direccion: String, lat: Double, lon: Double) {
        val opciones = arrayOf("🏠 Casa", "💼 Trabajo", "📍 Otro lugar (con nombre)")
        AlertDialog.Builder(this)
            .setTitle("Guardar en Mis lugares")
            .setItems(opciones) { _, w ->
                val l = leerLugares()
                when (w) {
                    0, 1 -> {
                        val t = if (w == 0) TIPO_CASA else TIPO_TRABAJO
                        l.removeAll { it.tipo == t }
                        l.add(MiLugar(System.currentTimeMillis(), titulo, direccion, lat, lon, t))
                        guardarLugares(l)
                        Toast.makeText(this, (if (w == 0) "Casa" else "Trabajo") + " guardada.", Toast.LENGTH_SHORT).show()
                    }
                    else -> {
                        if (l.count { it.tipo == TIPO_NORMAL } >= MAX_LUGARES) {
                            Toast.makeText(this, "Llegaste al máximo de $MAX_LUGARES lugares.", Toast.LENGTH_SHORT).show()
                        } else {
                            val campo = EditText(this).apply { setText(titulo); setSingleLine(); setSelectAllOnFocus(true) }
                            AlertDialog.Builder(this)
                                .setTitle("Nombre del lugar")
                                .setView(FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(campo) })
                                .setPositiveButton("Guardar") { _, _ ->
                                    val n = campo.text.toString().trim().ifEmpty { titulo }
                                    val l2 = leerLugares()
                                    l2.add(MiLugar(System.currentTimeMillis(), n, direccion, lat, lon, TIPO_NORMAL))
                                    guardarLugares(l2)
                                    Toast.makeText(this, "Guardado.", Toast.LENGTH_SHORT).show()
                                }
                                .setNegativeButton("Cancelar", null)
                                .show()
                        }
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun elegirDestino(titulo: String, lat: Double, lon: Double) {
        quitarPines()
        ocultarResultados()
        ocultarTeclado()
        destLat = lat
        destLon = lon
        destTitulo = titulo
        hayDestino = true
        ponerDestino(lat, lon)
        seguir = false
        rotacionAuto = false
        fijarRotacion(0f)
        mapView.setCenter(LatLong(lat, lon))
        if (mapView.model.mapViewPosition.zoomLevel < 15) mapView.setZoomLevel(15.toByte())
        calcularRuta(false)
    }

    private fun dibujarPin(colorPin: Int = 0xFFD32F2F.toInt()): android.graphics.Bitmap {
        val w = dp(34)
        val h = dp(46)
        val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rojo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = colorPin }
        val blanco = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
        val punta = Path().apply {
            moveTo(w * 0.16f, w * 0.66f)
            lineTo(w * 0.84f, w * 0.66f)
            lineTo(w / 2f, h.toFloat())
            close()
        }
        c.drawPath(punta, rojo)
        c.drawCircle(w / 2f, w / 2f, w * 0.46f, rojo)
        c.drawCircle(w / 2f, w / 2f, w * 0.18f, blanco)
        return bmp
    }

    private fun ponerDestino(lat: Double, lon: Double) {
        quitarDestino()
        val bmp = dibujarPin()
        val m = Marker(LatLong(lat, lon), AndroidGraphicFactory.convertToBitmap(BitmapDrawable(resources, bmp)), 0, -bmp.height / 2)
        mapView.layerManager.layers.add(m)
        capaDestino = m
        refrescarCursorArriba()
    }

    private fun quitarDestino() {
        capaDestino?.let {
            try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { }
        }
        capaDestino = null
    }

    /** Vuelve a poner el cursor encima de la ruta y del destino. */
    private fun refrescarCursorArriba() {
        val m = marcador
        if (m != null) {
            try { mapView.layerManager.layers.remove(m) } catch (e: Exception) { }
            marcador = null
            estiloDibujado = -1
        }
        ubicacion?.let { ponerMarcador(it) }
    }

    private fun dibujarRuta(r: Route) {
        capaRuta?.let {
            try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { }
        }
        val pintura = AndroidGraphicFactory.INSTANCE.createPaint()
        pintura.setColor(0xCC1565C0.toInt())
        pintura.setStrokeWidth(dp(7).toFloat())
        pintura.setStyle(org.mapsforge.core.graphics.Style.STROKE)
        val linea = Polyline(pintura, AndroidGraphicFactory.INSTANCE)
        for (i in 0 until r.puntos()) {
            linea.latLongs.add(LatLong(r.lat[i], r.lon[i]))
        }
        mapView.layerManager.layers.add(linea)
        capaRuta = linea
        refrescarCursorArriba()
    }

    private fun encuadrar(r: Route) {
        var minLat = r.lat[0]
        var maxLat = r.lat[0]
        var minLon = r.lon[0]
        var maxLon = r.lon[0]
        for (i in 0 until r.puntos()) {
            if (r.lat[i] < minLat) minLat = r.lat[i]
            if (r.lat[i] > maxLat) maxLat = r.lat[i]
            if (r.lon[i] < minLon) minLon = r.lon[i]
            if (r.lon[i] > maxLon) maxLon = r.lon[i]
        }
        val ancho = com.mapaoffline.gps.nav.Geo.dist(minLat, minLon, minLat, maxLon)
        val alto = com.mapaoffline.gps.nav.Geo.dist(minLat, minLon, maxLat, minLon)
        val m = Math.max(ancho, alto)
        val zoom = when {
            m < 800 -> 16
            m < 2000 -> 15
            m < 4000 -> 14
            m < 8000 -> 13
            m < 16000 -> 12
            m < 32000 -> 11
            else -> 10
        }
        seguir = false
        mapView.setCenter(LatLong((minLat + maxLat) / 2, (minLon + maxLon) / 2))
        mapView.setZoomLevel(zoom.toByte())
    }

    private fun acomodarBotones() {
        val lp = botones.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = if (panelRuta.visibility == View.VISIBLE) (if (navegando) dp(100) else dp(210)) else dp(36)
        botones.layoutParams = lp
    }

    private fun quitarPlanBus() {
        for (c in capasBus) {
            try { mapView.layerManager.layers.remove(c) } catch (e: Exception) { }
        }
        capasBus.clear()
        planesBus = emptyList()
    }

    private fun limpiarRuta() {
        quitarPlanBus()
        panelRuta.setPadding(dp(18), dp(14), dp(18), dp(14))
        capaRuta?.let {
            try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { }
        }
        capaRuta = null
        quitarDestino()
        ruta = null
        hayDestino = false
        panelRuta.visibility = View.GONE
        acomodarBotones()
    }

    private fun calcularRuta(reruteo: Boolean) {
        val kit = navKit ?: return
        if (!hayDestino || calculando) return
        val l = ubicacion
        if (l == null) {
            mostrarAvisoRuta("Todavía no hay señal GPS. Salí a un lugar abierto y tocá \"Calcular ruta\" cuando aparezca tu ubicación.")
            return
        }
        calculando = true
        val rumbo = if (l.hasBearing() && l.hasSpeed() && l.speed > 1.5f) l.bearing.toDouble() else -1.0
        val dLat = destLat
        val dLon = destLon
        val op = opcionesRuta()
        opRuta = op
        if (!reruteo) mostrarCalculando()
        Thread {
            var r: Route? = null
            var error = ""
            try {
                r = kit.router.ruta(l.latitude, l.longitude, dLat, dLon, rumbo, op)
            } catch (e: RutaException) {
                error = e.message ?: "No se pudo calcular la ruta."
            } catch (e: Throwable) {
                error = "No se pudo calcular la ruta."
            }
            main.post { alTerminarRuta(r, error, reruteo) }
        }.start()
    }

    private fun alTerminarRuta(r: Route?, error: String, reruteo: Boolean) {
        calculando = false
        if (!hayDestino) return
        if (r == null) {
            if (reruteo && navegando) {
                hablar("No pude calcular otra ruta")
                textoNav.text = "No pude recalcular. Sigo con la ruta anterior."
            } else {
                mostrarAvisoRuta(error)
            }
            return
        }
        ruta = r
        dibujarRuta(r)
        if (reruteo && navegando) {
            segmentoActual = 0
            anunciados.clear()
            val p = r.pasos[if (r.pasos.size > 1) 1 else 0]
            actualizarBanner(p, p.desde)
            hablar(r.pasos[0].texto())
        } else {
            encuadrar(r)
            mostrarVistaPrevia()
        }
    }

    private fun mostrarCalculando() {
        panelRuta.removeAllViews()
        panelRuta.addView(texto(destTitulo, 18f, Color.WHITE, true))
        panelRuta.addView(texto("Calculando la ruta…", 15f, 0xFFCFE3F2.toInt()).apply { setPadding(0, dp(4), 0, dp(10)) })
        panelRuta.addView(boton("Cancelar", false) { limpiarRuta() })
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
    }

    private fun mostrarAvisoRuta(mensaje: String) {
        panelRuta.removeAllViews()
        panelRuta.addView(texto(destTitulo, 18f, Color.WHITE, true))
        panelRuta.addView(texto(mensaje, 15f, 0xFFFFD0C8.toInt()).apply { setPadding(0, dp(4), 0, dp(10)) })
        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fila.addView(boton("Calcular ruta", true) { calcularRuta(false) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fila.addView(
            boton("Cancelar", false) { limpiarRuta() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) }
        )
        panelRuta.addView(fila)
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
    }

    private fun mostrarVistaPrevia() {
        val r = ruta ?: return
        panelRuta.removeAllViews()
        panelRuta.addView(texto(destTitulo, 18f, Color.WHITE, true))
        panelRuta.addView(
            texto(
                (if (opRuta.aPie) "🚶 A pie · " else "") +
                    "${Formato.distancia(r.distancia)} · ${Formato.tiempo(r.tiempo)} aprox." +
                    (if (opRuta.aPie) "" else " (sin tránsito)"),
                15f, 0xFFCFE3F2.toInt()
            ).apply { setPadding(0, dp(4), 0, dp(if (r.avisos.isEmpty()) 10 else 2)) }
        )
        for (a in r.avisos) {
            panelRuta.addView(texto("⚠ $a", 13f, 0xFFFFB74D.toInt()).apply { setPadding(0, 0, 0, dp(6)) })
        }
        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fila.addView(boton("Iniciar", true) { iniciarNavegacion() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fila.addView(
            boton("🚌", false) { calcularColectivo() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
        )
        fila.addView(
            boton("⭐", false) { guardarComo(destTitulo, "", destLat, destLon) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
        )
        fila.addView(
            boton("Cancelar", false) { limpiarRuta() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) }
        )
        panelRuta.addView(fila)
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
    }

    // ------------------------------------------------------------------ colectivos

    private fun calcularColectivo() {
        val br = busRouter
        if (br == null) {
            AlertDialog.Builder(this)
                .setTitle("Colectivos")
                .setMessage(
                    if (mapaActual != null && MapStore.busFile(this, mapaActual!!.nameWithoutExtension).exists()) "Se están cargando las líneas de colectivo. Probá de nuevo en unos segundos."
                    else "Todavía no bajaste las líneas de colectivo. Se bajan una sola vez, con internet, desde el botón Mapas → \"Bajar rutas, buscador y colectivos\"."
                )
                .setPositiveButton("Entendido", null)
                .show()
            return
        }
        val l = ubicacion
        if (l == null || !hayDestino) {
            Toast.makeText(this, "Hace falta tu ubicación (GPS) y un destino.", Toast.LENGTH_LONG).show()
            return
        }
        val oLat = l.latitude
        val oLon = l.longitude
        val dLat = destLat
        val dLon = destLon
        panelRuta.removeAllViews()
        panelRuta.addView(texto(destTitulo, 18f, Color.WHITE, true))
        panelRuta.addView(texto("Buscando colectivos…", 15f, 0xFFCFE3F2.toInt()).apply { setPadding(0, dp(4), 0, dp(10)) })
        panelRuta.addView(boton("Cancelar", false) { limpiarRuta() })
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
        Thread {
            var planes: List<BusRouter.Plan> = emptyList()
            try {
                planes = br.planificar(oLat, oLon, dLat, dLon)
            } catch (e: Throwable) {
            }
            main.post {
                if (!hayDestino) return@post
                planesBus = planes
                planBusActual = 0
                mostrarPlanColectivo()
            }
        }.start()
    }

    private fun minutos(seg: Double): String {
        val m = Math.round(seg / 60.0).toInt()
        return if (m < 60) "$m min" else "${m / 60} h ${m % 60} min"
    }

    private fun metrosTexto(m: Double): String = if (m < 1000) "${(Math.round(m / 10.0) * 10).toInt()} m" else "%.1f km".format(m / 1000.0)

    private fun mostrarPlanColectivo() {
        for (c in capasBus) {
            try { mapView.layerManager.layers.remove(c) } catch (e: Exception) { }
        }
        capasBus.clear()
        panelRuta.removeAllViews()
        panelRuta.addView(texto(destTitulo, 18f, Color.WHITE, true))
        val planes = planesBus
        if (planes.isEmpty()) {
            panelRuta.addView(
                texto(
                    "No encontré cómo llegar en colectivo (con hasta un trasbordo) desde acá. Puede que no haya líneas cargadas cerca, o que el destino quede lejos de una parada.",
                    14f, 0xFFFFD0C8.toInt()
                ).apply { setPadding(0, dp(4), 0, dp(10)) }
            )
            val f = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            f.addView(boton("Volver", true) { mostrarVistaPrevia(); ruta?.let { dibujarRuta(it) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            f.addView(boton("Cancelar", false) { limpiarRuta() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
            panelRuta.addView(f)
            panelRuta.visibility = View.VISIBLE
            acomodarBotones()
            return
        }
        val p = planes[planBusActual]
        capaRuta?.let { try { mapView.layerManager.layers.remove(it) } catch (e: Exception) { } }
        capaRuta = null
        panelRuta.addView(
            texto(
                "🚌 Opción ${planBusActual + 1} de ${planes.size} · línea ${p.claveLineas} · ${minutos(p.segundos)} aprox.",
                15f, 0xFFFFD54F.toInt(), true
            ).apply { setPadding(0, dp(4), 0, dp(4)) }
        )
        val detalle = StringBuilder()
        for (t in p.tramos) {
            if (t.enColectivo) {
                detalle.append("🚌 Tomá el ").append(t.linea).append(" en ").append(t.desde)
                    .append(" y bajate en ").append(t.hasta).append(" (").append(t.paradas).append(if (t.paradas == 1) " parada" else " paradas").append(")\n")
            } else if (t.metros >= 40) {
                detalle.append("🚶 Caminá ").append(metrosTexto(t.metros)).append(" hasta ").append(t.hasta).append("\n")
            }
        }
        panelRuta.addView(texto(detalle.toString().trim(), 14f, Color.WHITE).apply { setPadding(0, 0, 0, dp(4)) })
        panelRuta.addView(
            texto("Estimado: sin horarios, con ${minutos(com.mapaoffline.gps.bus.BusRouter.ESPERA_SEG)} de espera por colectivo. Las líneas pueden haber cambiado.", 12f, 0xFFB0BEC5.toInt())
                .apply { setPadding(0, 0, 0, dp(8)) }
        )
        val f = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        if (planes.size > 1) {
            f.addView(boton("Otra opción", true) {
                planBusActual = (planBusActual + 1) % planesBus.size
                mostrarPlanColectivo()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        f.addView(
            boton("A pie / auto", false) { quitarPlanBus(); mostrarVistaPrevia(); ruta?.let { dibujarRuta(it) } },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (planes.size > 1) leftMargin = dp(8) }
        )
        f.addView(boton("Cancelar", false) { limpiarRuta() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
        panelRuta.addView(f)
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
        dibujarPlanColectivo(p)
    }

    private fun dibujarPlanColectivo(p: BusRouter.Plan) {
        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
        for (t in p.tramos) {
            val pintura = AndroidGraphicFactory.INSTANCE.createPaint()
            pintura.setColor(if (t.enColectivo) 0xDDE65100.toInt() else 0xDD455A64.toInt())
            pintura.setStrokeWidth(dp(if (t.enColectivo) 7 else 5).toFloat())
            pintura.setStyle(org.mapsforge.core.graphics.Style.STROKE)
            if (!t.enColectivo) pintura.setDashPathEffect(floatArrayOf(dp(10).toFloat(), dp(8).toFloat()))
            val linea = Polyline(pintura, AndroidGraphicFactory.INSTANCE)
            for (i in t.lat.indices) {
                linea.latLongs.add(LatLong(t.lat[i], t.lon[i]))
                minLat = Math.min(minLat, t.lat[i]); maxLat = Math.max(maxLat, t.lat[i])
                minLon = Math.min(minLon, t.lon[i]); maxLon = Math.max(maxLon, t.lon[i])
            }
            mapView.layerManager.layers.add(linea)
            capasBus.add(linea)
            if (t.enColectivo) {
                for (idx in intArrayOf(0, t.lat.size - 1)) {
                    val bmp = dibujarPin(0xFFE65100.toInt())
                    val m = Marker(LatLong(t.lat[idx], t.lon[idx]), AndroidGraphicFactory.convertToBitmap(BitmapDrawable(resources, bmp)), 0, -bmp.height / 2)
                    mapView.layerManager.layers.add(m)
                    capasBus.add(m)
                }
            }
        }
        refrescarCursorArriba()
        val ancho = com.mapaoffline.gps.nav.Geo.dist(minLat, minLon, minLat, maxLon)
        val alto = com.mapaoffline.gps.nav.Geo.dist(minLat, minLon, maxLat, minLon)
        val m = Math.max(ancho, alto)
        val zoom = when {
            m < 800 -> 16
            m < 2000 -> 15
            m < 4000 -> 14
            m < 8000 -> 13
            m < 16000 -> 12
            m < 32000 -> 11
            else -> 10
        }
        seguir = false
        mapView.setCenter(LatLong((minLat + maxLat) / 2, (minLon + maxLon) / 2))
        mapView.setZoomLevel(zoom.toByte())
    }

    // ------------------------------------------------------------------ navegación

    private fun iniciarNavegacion() {
        val r = ruta ?: return
        navegando = true
        segmentoActual = 0
        fueraCont = 0
        rumboRuta = Float.NaN
        ultimoReruteo = 0L
        anunciados.clear()
        seguir = true
        pausaZoomHasta = 0L
        ultimoCambioZoom = 0L
        rotacionAuto = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        arriba.visibility = View.GONE
        ocultarResultados()
        bannerNav.visibility = View.VISIBLE
        mapView.setZoomLevel(17.toByte())
        ubicacion?.let { mapView.setCenter(LatLong(it.latitude, it.longitude)) }
        mostrarPanelNavegacion()
        val prox = r.pasos[if (r.pasos.size > 1) 1 else 0]
        actualizarBanner(prox, prox.desde)
        var frase = r.pasos[0].texto()
        if (r.pasos.size > 1) frase += ". " + Formato.avisoLejano(prox, prox.desde)
        hablar(frase)
    }

    private fun mostrarPanelNavegacion() {
        panelRuta.removeAllViews()
        panelRuta.setPadding(dp(16), dp(8), dp(10), dp(8))
        val fila = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val resumen = texto("", 17f, Color.WHITE, true)
        resumenNav = resumen
        fila.addView(resumen, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val bv = texto(if (vozActiva) "🔊" else "🔇", 24f).apply {
            gravity = Gravity.CENTER
            background = fondo(0x33FFFFFF, 20)
            setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener {
                vozActiva = !vozActiva
                text = if (vozActiva) "🔊" else "🔇"
                if (!vozActiva) {
                    try { tts?.stop() } catch (e: Exception) { }
                }
            }
        }
        botonVoz = bv
        val bn = texto(if (noche) "🌙" else "☀", 24f).apply {
            gravity = Gravity.CENTER
            background = fondo(0x33FFFFFF, 20)
            setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener { alternarNoche() }
        }
        botonNoche = bn
        fila.addView(bn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        fila.addView(bv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        panelRuta.addView(fila)
        panelRuta.visibility = View.VISIBLE
        acomodarBotones()
    }

    private fun actualizarBanner(p: Route.Paso, falta: Double) {
        flechaNav.text = Formato.flecha(p.tipo)
        distNav.text = Formato.distancia(falta)
        textoNav.text = if (p.tipo == Route.LLEGADA) "Tu destino: $destTitulo" else p.texto()
    }

    private var rumboRuta = Float.NaN

    /** El mapa gira para que el tramo de ruta que viene quede siempre hacia arriba del celular. */
    private fun orientarSegunRuta(r: Route, l: Location, seg: Int, progreso: Double) {
        val n = r.puntos()
        if (n < 2) return
        var j = Math.min(Math.max(seg + 1, 1), n - 1)
        while (j < n - 1 && r.cum[j] < progreso + 40.0) j++
        var lat2 = r.lat[j]
        var lon2 = r.lon[j]
        val dy = (lat2 - l.latitude) * 111320.0
        val dx = (lon2 - l.longitude) * 111320.0 * Math.cos(Math.toRadians(l.latitude))
        if (dx * dx + dy * dy < 25.0) {
            val k = Math.min(Math.max(seg, 0), n - 2)
            lat2 = r.lat[k + 1]
            lon2 = r.lon[k + 1]
            val y2 = (lat2 - r.lat[k]) * 111320.0
            val x2 = (lon2 - r.lon[k]) * 111320.0 * Math.cos(Math.toRadians(l.latitude))
            if (x2 * x2 + y2 * y2 < 0.01) return
            rumboRuta = ((Math.toDegrees(Math.atan2(x2, y2)) + 360.0) % 360.0).toFloat()
        } else {
            rumboRuta = ((Math.toDegrees(Math.atan2(dx, dy)) + 360.0) % 360.0).toFloat()
        }
        if (rotacionAuto && seguir) {
            var dif = -rumboRuta - rotacionMapa
            while (dif > 180f) dif -= 360f
            while (dif < -180f) dif += 360f
            fijarRotacion(if (Math.abs(dif) < 1f) rotacionMapa else rotacionMapa + dif * 0.4f)
        }
    }

    private fun avanzarNavegacion(l: Location) {
        val r = ruta ?: return
        if (calculando) return
        var u = r.ubicar(l.latitude, l.longitude, segmentoActual - 3, segmentoActual + 80)
        if (u == null || u.fuera > 40.0) {
            val g = r.ubicar(l.latitude, l.longitude)
            if (g != null && (u == null || g.fuera < u.fuera)) u = g
        }
        if (u == null) return
        val tolerancia = Math.max(35.0, l.accuracy * 1.5)
        if (u.fuera > tolerancia) {
            fueraCont++
            if (fueraCont >= 3) reruteo()
            return
        }
        fueraCont = 0
        segmentoActual = u.segmento
        val progreso = u.progreso
        recortarRuta(l, u.segmento)
        orientarSegunRuta(r, l, u.segmento, progreso)

        var prox = 1
        while (prox < r.pasos.size - 1 && r.pasos[prox].desde <= progreso + 3) prox++
        if (prox >= r.pasos.size) prox = r.pasos.size - 1
        val p = r.pasos[prox]
        val falta = Math.max(0.0, p.desde - progreso)
        actualizarBanner(p, falta)
        zoomAutomatico(falta, l.speed)

        val restante = Math.max(0.0, r.distancia - progreso)
        val segundos = if (r.distancia > 0) r.tiempo * restante / r.distancia else 0.0
        val llegada = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(System.currentTimeMillis() + (segundos * 1000).toLong()))
        resumenNav?.text = "${Formato.distancia(restante)} · ${Formato.tiempo(segundos)} · llegás ${llegada}"

        anunciar(r, prox, falta)
        if (prox == r.pasos.size - 1 && falta < 25.0) terminarNavegacion(true)
    }

    private fun anunciar(r: Route, j: Int, falta: Double) {
        val p = r.pasos[j]
        val desdeAnterior = p.desde - r.pasos[Math.max(0, j - 1)].desde
        val lejos = j * 10
        val cerca = j * 10 + 1
        val pie = opRuta.aPie
        val dLejos = if (pie) 150.0 else 350.0
        val dCerca = if (pie) 40.0 else 90.0
        if (falta <= dLejos && desdeAnterior > (if (pie) 200.0 else 450.0) && !anunciados.contains(lejos)) {
            anunciados.add(lejos)
            hablar(Formato.avisoLejano(p, falta))
        }
        if (falta <= dCerca && p.tipo != Route.LLEGADA && !anunciados.contains(cerca)) {
            anunciados.add(cerca)
            anunciados.add(lejos)
            hablar(p.texto())
        }
    }

    private fun reruteo() {
        val ahora = System.currentTimeMillis()
        if (calculando || ahora - ultimoReruteo < 8000L) return
        ultimoReruteo = ahora
        fueraCont = 0
        textoNav.text = "Recalculando…"
        hablar("Recalculando")
        calcularRuta(true)
    }

    private fun terminarNavegacion(llego: Boolean) {
        navegando = false
        rotacionAuto = false
        fijarRotacion(0f)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        bannerNav.visibility = View.GONE
        arriba.visibility = View.VISIBLE
        if (llego) {
            hablar("Llegaste a tu destino")
            Toast.makeText(this, "Llegaste a tu destino", Toast.LENGTH_LONG).show()
        } else {
            try { tts?.stop() } catch (e: Exception) { }
        }
        limpiarRuta()
    }

    // ------------------------------------------------------------------ voz

    private fun iniciarVoz() {
        tts = TextToSpeech(this) { estadoVoz ->
            if (estadoVoz == TextToSpeech.SUCCESS) {
                val t = tts
                if (t != null) {
                    var r = t.setLanguage(Locale("es", "AR"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        r = t.setLanguage(Locale("es"))
                    }
                    ttsListo = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                }
            }
        }
    }

    private fun hablar(texto: String) {
        if (!vozActiva || !ttsListo) return
        try {
            tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "nav")
        } catch (e: Exception) {
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            navegando -> terminarNavegacion(false)
            scrollResultados.visibility == View.VISIBLE -> ocultarResultados()
            pines.isNotEmpty() -> quitarPines()
            hayDestino -> limpiarRuta()
            else -> finishAffinity()
        }
    }

    companion object {
        private const val PEDIDO_UBICACION = 10
        private const val PEDIDO_ARCHIVO = 11
        private const val PEDIDO_VOZ = 12
    }
}
