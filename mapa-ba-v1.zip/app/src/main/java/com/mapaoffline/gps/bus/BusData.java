package com.mapaoffline.gps.bus;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/** Líneas y paradas de colectivo cargadas de un archivo .bus (ver tools/build_bus.py). */
public final class BusData {
    public static final int MAGIC = 0x31535542;

    public final int nStops, nRoutes;
    public final double[] sLat, sLon;
    public final String[] sNombre;
    public final String[] rEtiqueta;
    /** Paradas de cada recorrido, en orden: rStart[r] .. rStart[r+1]-1 dentro de entries. */
    public final int[] rStart, entries;
    /** Para cada parada, los recorridos que pasan: spStart[s]..spStart[s+1]-1 dentro de spRoute / spPos. */
    public final int[] spStart, spRoute, spPos;
    /** Distancia acumulada (m) sobre cada recorrido, en línea recta entre paradas. */
    public final double[] cum;

    // grilla para buscar paradas cerca de un punto
    static final double CELDA = 0.003; // grados (unos 330 m)
    final double minLat, minLon;
    final int gW, gH;
    final int[] gStart, gList;

    public static boolean esValido(File f) {
        if (!f.exists() || f.length() < 24) return false;
        try {
            RandomAccessFile raf = new RandomAccessFile(f, "r");
            try {
                ByteBuffer h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
                raf.getChannel().read(h, 0);
                h.flip();
                if (h.getInt() != MAGIC) return false;
                long nStops = h.getInt(), nRoutes = h.getInt(), nEntries = h.getInt(), nStr = h.getInt(), blob = h.getInt();
                long esperado = 24 + 4L * (3 * nStops + nRoutes + (nRoutes + 1) + nEntries + (nStr + 1)) + blob;
                return esperado == f.length() && nRoutes > 0;
            } finally {
                raf.close();
            }
        } catch (IOException e) {
            return false;
        }
    }

    public static BusData cargar(File f) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(f, "r");
        try {
            ByteBuffer bb = ByteBuffer.allocate((int) raf.length()).order(ByteOrder.LITTLE_ENDIAN);
            FileChannel ch = raf.getChannel();
            while (bb.hasRemaining()) if (ch.read(bb) < 0) break;
            bb.flip();
            return new BusData(bb);
        } finally {
            raf.close();
        }
    }

    public BusData(ByteBuffer bb) throws IOException {
        if (bb.getInt() != MAGIC) throw new IOException("No es un archivo de colectivos");
        nStops = bb.getInt();
        nRoutes = bb.getInt();
        int nEntries = bb.getInt();
        int nStr = bb.getInt();
        int blobLen = bb.getInt();
        sLat = new double[nStops];
        sLon = new double[nStops];
        for (int i = 0; i < nStops; i++) sLat[i] = bb.getInt() / 1e6;
        for (int i = 0; i < nStops; i++) sLon[i] = bb.getInt() / 1e6;
        int[] nom = new int[nStops];
        for (int i = 0; i < nStops; i++) nom[i] = bb.getInt();
        int[] lab = new int[nRoutes];
        for (int i = 0; i < nRoutes; i++) lab[i] = bb.getInt();
        rStart = new int[nRoutes + 1];
        for (int i = 0; i <= nRoutes; i++) rStart[i] = bb.getInt();
        entries = new int[nEntries];
        for (int i = 0; i < nEntries; i++) entries[i] = bb.getInt();
        int[] offs = new int[nStr + 1];
        for (int i = 0; i <= nStr; i++) offs[i] = bb.getInt();
        byte[] blob = new byte[blobLen];
        bb.get(blob);
        Charset utf8 = Charset.forName("UTF-8");
        String[] textos = new String[nStr];
        for (int i = 0; i < nStr; i++) textos[i] = new String(blob, offs[i], offs[i + 1] - offs[i], utf8);
        sNombre = new String[nStops];
        for (int i = 0; i < nStops; i++) sNombre[i] = nom[i] < 0 ? "" : textos[nom[i]];
        rEtiqueta = new String[nRoutes];
        for (int i = 0; i < nRoutes; i++) rEtiqueta[i] = lab[i] < 0 ? "?" : textos[lab[i]];

        cum = new double[nEntries];
        int[] deg = new int[nStops];
        for (int r = 0; r < nRoutes; r++) {
            for (int e = rStart[r]; e < rStart[r + 1]; e++) {
                int s = entries[e];
                deg[s]++;
                cum[e] = e == rStart[r] ? 0 : cum[e - 1] + dist(sLat[entries[e - 1]], sLon[entries[e - 1]], sLat[s], sLon[s]);
            }
        }
        spStart = new int[nStops + 1];
        for (int s = 0; s < nStops; s++) spStart[s + 1] = spStart[s] + deg[s];
        spRoute = new int[nEntries];
        spPos = new int[nEntries];
        int[] fill = new int[nStops];
        for (int r = 0; r < nRoutes; r++) {
            for (int e = rStart[r]; e < rStart[r + 1]; e++) {
                int s = entries[e];
                int k = spStart[s] + fill[s]++;
                spRoute[k] = r;
                spPos[k] = e - rStart[r];
            }
        }

        double mnLat = 90, mnLon = 180, mxLat = -90, mxLon = -180;
        for (int s = 0; s < nStops; s++) {
            mnLat = Math.min(mnLat, sLat[s]);
            mxLat = Math.max(mxLat, sLat[s]);
            mnLon = Math.min(mnLon, sLon[s]);
            mxLon = Math.max(mxLon, sLon[s]);
        }
        if (nStops == 0) { mnLat = mnLon = mxLat = mxLon = 0; }
        minLat = mnLat;
        minLon = mnLon;
        gW = (int) ((mxLon - mnLon) / CELDA) + 1;
        gH = (int) ((mxLat - mnLat) / CELDA) + 1;
        gStart = new int[gW * gH + 1];
        int[] celda = new int[nStops];
        for (int s = 0; s < nStops; s++) {
            celda[s] = celdaDe(sLat[s], sLon[s]);
            gStart[celda[s] + 1]++;
        }
        for (int i = 0; i < gW * gH; i++) gStart[i + 1] += gStart[i];
        gList = new int[nStops];
        int[] pos = new int[gW * gH];
        for (int s = 0; s < nStops; s++) gList[gStart[celda[s]] + pos[celda[s]]++] = s;
    }

    private int celdaDe(double lat, double lon) {
        int cx = (int) ((lon - minLon) / CELDA), cy = (int) ((lat - minLat) / CELDA);
        if (cx < 0) cx = 0;
        if (cy < 0) cy = 0;
        if (cx >= gW) cx = gW - 1;
        if (cy >= gH) cy = gH - 1;
        return cy * gW + cx;
    }

    public static double dist(double lat1, double lon1, double lat2, double lon2) {
        double dy = (lat2 - lat1) * 111320.0;
        double dx = (lon2 - lon1) * 111320.0 * Math.cos(Math.toRadians((lat1 + lat2) * 0.5));
        return Math.sqrt(dx * dx + dy * dy);
    }

    /** Paradas a menos de radio metros del punto. */
    public List<Integer> paradasCerca(double lat, double lon, double radio) {
        List<Integer> res = new ArrayList<Integer>();
        if (nStops == 0) return res;
        double dLat = radio / 111320.0;
        double dLon = radio / (111320.0 * Math.max(0.2, Math.cos(Math.toRadians(lat))));
        int x0 = (int) Math.floor((lon - dLon - minLon) / CELDA), x1 = (int) Math.floor((lon + dLon - minLon) / CELDA);
        int y0 = (int) Math.floor((lat - dLat - minLat) / CELDA), y1 = (int) Math.floor((lat + dLat - minLat) / CELDA);
        x0 = Math.max(x0, 0); y0 = Math.max(y0, 0);
        x1 = Math.min(x1, gW - 1); y1 = Math.min(y1, gH - 1);
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                int c = y * gW + x;
                for (int k = gStart[c]; k < gStart[c + 1]; k++) {
                    int s = gList[k];
                    if (dist(lat, lon, sLat[s], sLon[s]) <= radio) res.add(s);
                }
            }
        }
        return res;
    }
}
