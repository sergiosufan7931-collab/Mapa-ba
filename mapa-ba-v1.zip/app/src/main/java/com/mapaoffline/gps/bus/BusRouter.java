package com.mapaoffline.gps.bus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * "Cómo llegar en colectivo": busca recorridos directos y con un solo trasbordo.
 * No hay horarios ni frecuencias en los datos: la espera se estima con un valor fijo.
 */
public final class BusRouter {
    public static final double CAMINATA_M_S = 1.25;        // 4,5 km/h
    public static final double RODEO_CAMINATA = 1.3;       // la calle no es una línea recta
    public static final double COLE_M_S = 4.7;             // unos 17 km/h en promedio
    public static final double RODEO_COLE = 1.15;
    public static final double SEG_POR_PARADA = 20;
    public static final double ESPERA_SEG = 600;           // espera estimada de cada colectivo
    public static final double PENA_TRASBORDO_SEG = 240;   // para preferir el directo si es parecido
    public static final double RADIO_INICIO_M = 700;
    public static final double RADIO_FIN_M = 700;
    public static final double RADIO_TRASBORDO_M = 400;
    public static final int MAX_OPCIONES = 3;

    /** Un tramo del viaje: a pie o en colectivo. */
    public static final class Tramo {
        public boolean enColectivo;
        public String linea = "";          // etiqueta del recorrido (solo colectivo)
        public String desde = "", hasta = "";   // nombres de paradas / lugares
        public int paradas;                // paradas que se recorren (solo colectivo)
        public double metros, segundos;
        public double[] lat, lon;          // línea para dibujar
    }

    public static final class Plan {
        public final List<Tramo> tramos = new ArrayList<Tramo>();
        public double segundos;            // tiempo total estimado
        public double costo;               // para ordenar (incluye penalidades)
        public int trasbordos;
        public String claveLineas = "";

        public double caminataMetros() {
            double m = 0;
            for (Tramo t : tramos) if (!t.enColectivo) m += t.metros;
            return m;
        }
    }

    private final BusData d;

    public BusRouter(BusData d) { this.d = d; }

    private static double caminar(double m) { return m * RODEO_CAMINATA / CAMINATA_M_S; }

    /** Segundos de viaje desde la posición a hasta la b (a < b) del recorrido r. */
    private double viaje(int r, int a, int b) {
        int e0 = d.rStart[r];
        double m = d.cum[e0 + b] - d.cum[e0 + a];
        return m * RODEO_COLE / COLE_M_S + (b - a) * SEG_POR_PARADA;
    }

    private int parada(int r, int pos) { return d.entries[d.rStart[r] + pos]; }

    /** Costo mínimo de ir desde cada posición de un recorrido hasta el destino bajando más adelante. */
    private static final class HaciaDestino {
        double[] costo;   // desde la posición m: viaje hasta bajar + caminata final
        int[] baja;       // posición donde conviene bajar
    }

    private static class Cand {
        int rA = -1, iA, k, rB = -1, pB, j;
        int paradaSube, paradaBaja;
        double costo, seg;
    }

    public List<Plan> planificar(double oLat, double oLon, double dLat, double dLon) {
        List<Plan> res = new ArrayList<Plan>();
        if (d.nStops == 0) return res;
        List<Integer> cercaO = d.paradasCerca(oLat, oLon, RADIO_INICIO_M);
        List<Integer> cercaD = d.paradasCerca(dLat, dLon, RADIO_FIN_M);
        if (cercaO.isEmpty() || cercaD.isEmpty()) return res;

        Map<Integer, Double> mapO = new HashMap<Integer, Double>();
        for (int s : cercaO) mapO.put(s, caminar(BusData.dist(oLat, oLon, d.sLat[s], d.sLon[s])));
        Map<Integer, Double> mapD = new HashMap<Integer, Double>();
        for (int s : cercaD) mapD.put(s, caminar(BusData.dist(dLat, dLon, d.sLat[s], d.sLon[s])));

        // recorridos que llegan cerca del destino
        Map<Integer, HaciaDestino> haciaDest = new HashMap<Integer, HaciaDestino>();
        Set<Integer> rutasD = new HashSet<Integer>();
        for (int s : cercaD) for (int k = d.spStart[s]; k < d.spStart[s + 1]; k++) rutasD.add(d.spRoute[k]);
        for (int r : rutasD) {
            int n = d.rStart[r + 1] - d.rStart[r];
            HaciaDestino h = new HaciaDestino();
            h.costo = new double[n];
            h.baja = new int[n];
            double mejor = Double.POSITIVE_INFINITY;
            int mejorJ = -1;
            for (int m = n - 1; m >= 0; m--) {
                h.costo[m] = mejor == Double.POSITIVE_INFINITY ? mejor : mejor - baseG(r, m);
                h.baja[m] = mejorJ;
                Double wd = mapD.get(parada(r, m));
                if (wd != null) {
                    double g = baseG(r, m) + wd;
                    if (g < mejor) { mejor = g; mejorJ = m; }
                }
            }
            haciaDest.put(r, h);
        }
        if (haciaDest.isEmpty()) return res;

        Map<String, Cand> mejores = new HashMap<String, Cand>();

        for (int s : cercaO) {
            double wo = mapO.get(s);
            for (int q = d.spStart[s]; q < d.spStart[s + 1]; q++) {
                int rA = d.spRoute[q], iA = d.spPos[q];
                int nA = d.rStart[rA + 1] - d.rStart[rA];
                // directo
                HaciaDestino hd = haciaDest.get(rA);
                if (hd != null && hd.baja[iA] >= 0) {
                    Cand c = new Cand();
                    c.rA = rA; c.iA = iA; c.k = hd.baja[iA]; c.paradaSube = s; c.paradaBaja = parada(rA, c.k);
                    c.seg = wo + ESPERA_SEG + hd.costo[iA];
                    c.costo = c.seg;
                    guardar(mejores, c, claveDe(rA, -1));
                }
                // con un trasbordo
                for (int k = iA + 1; k < nA; k++) {
                    int sk = parada(rA, k);
                    double tA = wo + ESPERA_SEG + viaje(rA, iA, k);
                    List<Integer> cercanas = d.paradasCerca(d.sLat[sk], d.sLon[sk], RADIO_TRASBORDO_M);
                    for (int m : cercanas) {
                        double wk = m == sk ? 0 : caminar(BusData.dist(d.sLat[sk], d.sLon[sk], d.sLat[m], d.sLon[m]));
                        for (int u = d.spStart[m]; u < d.spStart[m + 1]; u++) {
                            int rB = d.spRoute[u];
                            if (rB == rA) continue;
                            HaciaDestino hb = haciaDest.get(rB);
                            if (hb == null) continue;
                            int pB = d.spPos[u];
                            if (hb.baja[pB] < 0) continue;
                            double seg = tA + wk + ESPERA_SEG + hb.costo[pB];
                            Cand c = new Cand();
                            c.rA = rA; c.iA = iA; c.k = k; c.rB = rB; c.pB = pB; c.j = hb.baja[pB];
                            c.paradaSube = s; c.paradaBaja = parada(rB, c.j);
                            c.seg = seg;
                            c.costo = seg + PENA_TRASBORDO_SEG;
                            guardar(mejores, c, claveDe(rA, rB));
                        }
                    }
                }
            }
        }

        List<Cand> lista = new ArrayList<Cand>(mejores.values());
        Collections.sort(lista, new Comparator<Cand>() {
            public int compare(Cand a, Cand b) { return Double.compare(a.costo, b.costo); }
        });
        // una sola opción por combinación de números de línea
        Set<String> vistas = new HashSet<String>();
        Set<String> directas = new HashSet<String>();
        for (Cand c : lista) {
            String clave = numero(c.rA) + (c.rB >= 0 ? ">" + numero(c.rB) : "");
            if (!vistas.add(clave)) continue;
            // si ya hay un directo con esa línea, no se ofrece lo mismo con trasbordo
            if (c.rB >= 0 && directas.contains(numero(c.rA))) continue;
            if (c.rB < 0) directas.add(numero(c.rA));
            res.add(armar(c, oLat, oLon, dLat, dLon));
            if (res.size() >= MAX_OPCIONES) break;
        }
        return res;
    }

    /** Parte del costo que no depende de dónde se sube: viaje acumulado hasta la posición m. */
    private double baseG(int r, int m) {
        int e0 = d.rStart[r];
        return d.cum[e0 + m] * RODEO_COLE / COLE_M_S + m * SEG_POR_PARADA;
    }

    private String claveDe(int rA, int rB) { return rA + ":" + rB; }

    private void guardar(Map<String, Cand> mejores, Cand c, String clave) {
        Cand x = mejores.get(clave);
        if (x == null || c.costo < x.costo) mejores.put(clave, c);
    }

    private String numero(int r) {
        String e = d.rEtiqueta[r];
        int i = e.indexOf(' ');
        return i < 0 ? e : e.substring(0, i);
    }

    private String nombreParada(int s) {
        String n = d.sNombre[s];
        return n == null || n.isEmpty() ? "parada" : n;
    }

    private Tramo caminata(double aLat, double aLon, double bLat, double bLon, String desde, String hasta) {
        Tramo t = new Tramo();
        t.enColectivo = false;
        t.metros = BusData.dist(aLat, aLon, bLat, bLon) * RODEO_CAMINATA;
        t.segundos = caminar(BusData.dist(aLat, aLon, bLat, bLon));
        t.lat = new double[]{aLat, bLat};
        t.lon = new double[]{aLon, bLon};
        t.desde = desde;
        t.hasta = hasta;
        return t;
    }

    private Tramo colectivo(int r, int a, int b) {
        Tramo t = new Tramo();
        t.enColectivo = true;
        t.linea = d.rEtiqueta[r].trim();
        t.paradas = b - a;
        int n = b - a + 1;
        t.lat = new double[n];
        t.lon = new double[n];
        for (int i = 0; i < n; i++) {
            int s = parada(r, a + i);
            t.lat[i] = d.sLat[s];
            t.lon[i] = d.sLon[s];
        }
        t.desde = nombreParada(parada(r, a));
        t.hasta = nombreParada(parada(r, b));
        t.metros = d.cum[d.rStart[r] + b] - d.cum[d.rStart[r] + a];
        t.segundos = viaje(r, a, b);
        return t;
    }

    private Plan armar(Cand c, double oLat, double oLon, double dLat, double dLon) {
        Plan p = new Plan();
        int sSube = c.paradaSube;
        p.tramos.add(caminata(oLat, oLon, d.sLat[sSube], d.sLon[sSube], "tu ubicación", "la parada " + nombreParada(sSube)));
        p.tramos.add(colectivo(c.rA, c.iA, c.k));
        p.claveLineas = numero(c.rA);
        if (c.rB >= 0) {
            int sk = parada(c.rA, c.k);
            int sm = parada(c.rB, c.pB);
            if (sm != sk) {
                p.tramos.add(caminata(d.sLat[sk], d.sLon[sk], d.sLat[sm], d.sLon[sm], "la parada " + nombreParada(sk), "la parada " + nombreParada(sm)));
            }
            p.tramos.add(colectivo(c.rB, c.pB, c.j));
            p.claveLineas += " + " + numero(c.rB);
            p.trasbordos = 1;
        }
        int sBaja = c.paradaBaja;
        p.tramos.add(caminata(d.sLat[sBaja], d.sLon[sBaja], dLat, dLon, "la parada " + nombreParada(sBaja), "tu destino"));
        double total = 0;
        for (Tramo t : p.tramos) total += t.segundos;
        total += ESPERA_SEG * (1 + p.trasbordos);
        p.segundos = total;
        p.costo = c.costo;
        return p;
    }
}
