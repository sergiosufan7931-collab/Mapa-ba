package com.mapaoffline.gps.nav;

/** Cuentas simples sobre coordenadas (precisión de sobra para una ciudad). */
public final class Geo {
    private Geo() {}

    public static final double M_POR_GRADO = 111320.0;

    public static double dist(double lat1, double lon1, double lat2, double lon2) {
        double dy = (lat2 - lat1) * M_POR_GRADO;
        double dx = (lon2 - lon1) * M_POR_GRADO * Math.cos(Math.toRadians((lat1 + lat2) * 0.5));
        return Math.sqrt(dx * dx + dy * dy);
    }

    /** Rumbo en grados (0 = norte, 90 = este) desde el punto 1 hacia el punto 2. */
    public static double rumbo(double lat1, double lon1, double lat2, double lon2) {
        double dy = lat2 - lat1;
        double dx = (lon2 - lon1) * Math.cos(Math.toRadians((lat1 + lat2) * 0.5));
        double r = Math.toDegrees(Math.atan2(dx, dy));
        if (r < 0) r += 360.0;
        return r;
    }

    /** Diferencia entre dos rumbos, entre -180 y 180 (positivo = hacia la derecha). */
    public static double giro(double desde, double hasta) {
        double d = (hasta - desde) % 360.0;
        if (d > 180.0) d -= 360.0;
        if (d <= -180.0) d += 360.0;
        return d;
    }
}
