plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

base {
    archivesName.set("Mapa-BA")
}

android {
    namespace = "com.mapaoffline.gps"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mapaba.colectivos"
        minSdk = 26
        targetSdk = 34
        versionCode = 1 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0)
        versionName = "1.0"
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    // Firma fija: la misma clave en todas las versiones. Si se cambia, Android obliga a desinstalar para actualizar.
    signingConfigs {
        create("fija") {
            storeFile = file("mapa.jks")
            storePassword = "mb7Kq29xLw4TzR8vN3cY"
            keyAlias = "mapaba"
            keyPassword = "mb7Kq29xLw4TzR8vN3cY"
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("fija")
            isMinifyEnabled = false
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fija")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")

    val mapsforge = "0.21.0"
    implementation("org.mapsforge:mapsforge-core:$mapsforge")
    implementation("org.mapsforge:mapsforge-map:$mapsforge")
    implementation("org.mapsforge:mapsforge-map-reader:$mapsforge")
    implementation("org.mapsforge:mapsforge-themes:$mapsforge")
    implementation("org.mapsforge:mapsforge-map-android:$mapsforge")
    implementation("com.caverock:androidsvg:1.4")
}
