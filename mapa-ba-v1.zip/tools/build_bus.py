#!/usr/bin/env python3
"""Arma buenos-aires.bus a partir de las líneas de colectivo de OpenStreetMap (relaciones route=bus).

Uso: build_bus.py colectivos.osm salida.bus

Formato (int32 little-endian):
  magic 'BUS1' (0x31535542), nStops, nRoutes, nEntries, nStr, blobLen
  stopLat[nStops], stopLon[nStops] (microgrados), stopName[nStops] (índice de texto, -1 = sin nombre)
  routeLabel[nRoutes] (índice de texto), routeStart[nRoutes+1], entries[nEntries] (índices de parada)
  strOff[nStr+1], blob (UTF-8)
"""
import math
import struct
import sys
import xml.etree.ElementTree as ET

STOP_ROLES = ("stop", "stop_entry_only", "stop_exit_only")
PLAT_ROLES = ("platform", "platform_entry_only", "platform_exit_only")
PASO_VIRTUAL_M = 300.0  # si la línea no tiene paradas cargadas, se ponen paradas cada tanto sobre el recorrido


def dist(a, b):
    dy = (b[0] - a[0]) * 111320.0
    dx = (b[1] - a[1]) * 111320.0 * math.cos(math.radians((a[0] + b[0]) / 2))
    return math.hypot(dx, dy)


def leer(path):
    rels = []
    need_nodes = set()
    need_ways = set()
    for ev, el in ET.iterparse(path, events=("end",)):
        if el.tag == "relation":
            tags = {t.get("k"): t.get("v") for t in el.findall("tag")}
            if tags.get("type") == "route" and tags.get("route") in ("bus", "trolleybus"):
                miembros = [(m.get("type"), int(m.get("ref")), m.get("role") or "") for m in el.findall("member")]
                rels.append((int(el.get("id")), tags, miembros))
                for t, r, _ in miembros:
                    if t == "node":
                        need_nodes.add(r)
                    elif t == "way":
                        need_ways.add(r)
            el.clear()
        elif el.tag in ("node", "way"):
            el.clear()
    # segunda pasada: coordenadas y recorridos de lo que se necesita
    ways = {}
    for ev, el in ET.iterparse(path, events=("end",)):
        if el.tag == "way":
            wid = int(el.get("id"))
            if wid in need_ways:
                refs = [int(n.get("ref")) for n in el.findall("nd")]
                ways[wid] = refs
            el.clear()
    for refs in ways.values():
        need_nodes.update(refs)
    nodes = {}
    nombres_nodo = {}
    for ev, el in ET.iterparse(path, events=("end",)):
        if el.tag == "node":
            nid = int(el.get("id"))
            if nid in need_nodes:
                nodes[nid] = (float(el.get("lat")), float(el.get("lon")))
                for t in el.findall("tag"):
                    if t.get("k") == "name":
                        nombres_nodo[nid] = t.get("v")
            el.clear()
    return rels, nodes, nombres_nodo, ways


def cadena_de_vias(miembros, ways):
    """Une las vías del recorrido en una sola lista de nodos, dándolas vuelta si hace falta."""
    pts = []
    for t, r, role in miembros:
        if t != "way" or r not in ways or role in ("platform", "stop"):
            continue
        refs = ways[r]
        if not refs:
            continue
        if pts:
            if pts[-1] == refs[0]:
                pts.extend(refs[1:])
            elif pts[-1] == refs[-1]:
                pts.extend(reversed(refs[:-1]))
            elif pts[0] == refs[0] or pts[0] == refs[-1]:
                pts.reverse()
                if pts[-1] == refs[0]:
                    pts.extend(refs[1:])
                else:
                    pts.extend(reversed(refs[:-1]))
            else:
                pts.extend(refs)
        else:
            pts.extend(refs)
    return pts


def main():
    entrada, salida = sys.argv[1], sys.argv[2]
    rels, nodes, nombres, ways = leer(entrada)

    stops = []        # (lat, lon, nombre)
    stop_de_nodo = {}
    rutas = []        # (label, [stop idx])
    sin_paradas = 0

    def parada(nid):
        if nid in stop_de_nodo:
            return stop_de_nodo[nid]
        p = nodes[nid]
        stops.append((p[0], p[1], nombres.get(nid, "")))
        stop_de_nodo[nid] = len(stops) - 1
        return stop_de_nodo[nid]

    for rid, tags, miembros in rels:
        def puntos(roles):
            res = []
            for t, r, role in miembros:
                if role not in roles:
                    continue
                if t == "node" and r in nodes:
                    res.append(r)
                elif t == "way" and r in ways and ways[r] and ways[r][0] in nodes:
                    # parada dibujada como vía: se usa el nodo del medio
                    refs = [x for x in ways[r] if x in nodes]
                    if refs:
                        res.append(refs[len(refs) // 2])
            return res

        ids = puntos(STOP_ROLES) or puntos(PLAT_ROLES)
        seq = []
        if ids:
            for nid in ids:
                s = parada(nid)
                if not seq or seq[-1] != s:
                    seq.append(s)
        else:
            cadena = [n for n in cadena_de_vias(miembros, ways) if n in nodes]
            if len(cadena) >= 2:
                sin_paradas += 1
                acum = 0.0
                ult = cadena[0]
                virt = [ult]
                for n in cadena[1:]:
                    acum += dist(nodes[ult], nodes[n])
                    ult = n
                    if acum >= PASO_VIRTUAL_M:
                        virt.append(n)
                        acum = 0.0
                if virt[-1] != cadena[-1]:
                    virt.append(cadena[-1])
                for nid in virt:
                    s = parada(nid)
                    if not seq or seq[-1] != s:
                        seq.append(s)
        if len(seq) < 2:
            continue
        ref = (tags.get("ref") or tags.get("name") or "?").strip().replace(" ", "")
        hacia = tags.get("to") or ""
        if not hacia:
            nom = tags.get("name") or ""
            hacia = nom.split("=>")[-1].split("→")[-1].split("->")[-1].strip() if nom else ""
        rutas.append((ref + " " + ("a " + hacia if hacia else ""), seq))

    textos = []
    idx_texto = {}

    def texto(t):
        if not t:
            return -1
        if t not in idx_texto:
            idx_texto[t] = len(textos)
            textos.append(t)
        return idx_texto[t]

    st_name = [texto(s[2]) for s in stops]
    labels = [texto(r[0].strip()) for r in rutas]
    start = [0]
    entries = []
    for _, seq in rutas:
        entries.extend(seq)
        start.append(len(entries))
    blob = b""
    offs = [0]
    for t in textos:
        blob += t.encode("utf-8")
        offs.append(len(blob))

    with open(salida, "wb") as f:
        f.write(struct.pack("<6i", 0x31535542, len(stops), len(rutas), len(entries), len(textos), len(blob)))
        for fmt, arr in (
            ("i", [int(round(s[0] * 1e6)) for s in stops]),
            ("i", [int(round(s[1] * 1e6)) for s in stops]),
            ("i", st_name),
            ("i", labels),
            ("i", start),
            ("i", entries),
            ("i", offs),
        ):
            f.write(struct.pack("<%di" % len(arr), *arr))
        f.write(blob)
    print("paradas:", len(stops), "recorridos:", len(rutas), "(sin paradas cargadas, con paradas virtuales:", sin_paradas, ")")


if __name__ == "__main__":
    main()
