#!/usr/bin/env python3
"""
Genera el archivo .nav (rutas + buscador sin conexión) para la app Mapa Offline GPS.

Uso:  build_nav.py calles.osm lugares.geojsonseq salida.nav

  calles.osm          XML de OpenStreetMap con SOLO las calles (osmium tags-filter + osmium cat)
  lugares.geojsonseq  GeoJSON secuencial con direcciones y lugares (osmium export)
  salida.nav          archivo binario que lee la app (enteros de 32 bits, little endian)

Formato (todo int32 little endian):
  cabecera 14 ints: magic, version, nV, nL, nShape, nNames, nNameInts, nAddr, nPoi, nPoiInts,
                    minLat, minLon, maxLat, maxLon           (grados * 1e6)
  vLat[nV] vLon[nV]
  linkA[nL] linkB[nL] linkLen[nL](m) linkCost[nL](décimas de s) linkName[nL](-1 = sin nombre)
  linkFlags[nL] linkShapeStart[nL+1]
  shapeLat[nShape] shapeLon[nShape]            (puntos intermedios, sin los extremos)
  nameOff[nNames+1] (bytes)  nameBytes (UTF-8, relleno a 4 bytes, nNameInts ints)
  addrStreet[nAddr] addrNum[nAddr] addrLat[nAddr] addrLon[nAddr]   (ordenado por calle, número)
  poiLat[nPoi] poiLon[nPoi] poiKind[nPoi] poiOff[nPoi+1] poiBytes (nPoiInts ints)

  flags de una calle: bits 0-3 clase (0 autopista,1 troncal,2 primaria,3 secundaria,4 terciaria,
  5 sin clasificar,6 residencial,7 servicio,8 calle de convivencia,9 otra),
  bits 4-5 sentido (0 doble, 1 solo A->B, 2 solo B->A), bit 6 rotonda,
  bit 7 (128) calle con peaje, bit 8 (256) calle que cruza una vía de tren a nivel.
"""
import sys, json, math, array, bisect, re
import xml.etree.ElementTree as ET

MAGIC = 0x3156414E  # 'NAV1'
VERSION = 1

# clase, velocidad urbana típica (km/h) -- velocidades conservadoras para una ciudad
HIGHWAYS = {
    'motorway': (0, 80), 'motorway_link': (0, 45),
    'trunk': (1, 60), 'trunk_link': (1, 40),
    'primary': (2, 40), 'primary_link': (2, 30),
    'secondary': (3, 35), 'secondary_link': (3, 28),
    'tertiary': (4, 30), 'tertiary_link': (4, 25),
    'unclassified': (5, 28), 'residential': (6, 25),
    'service': (7, 15), 'living_street': (8, 12), 'road': (9, 25),
}
NO_SERVICE = {'driveway', 'parking_aisle', 'drive-through', 'emergency_access'}


def dist_m(la1, lo1, la2, lo2):
    dy = (la2 - la1) * 1e-6 * 111320.0
    dx = (lo2 - lo1) * 1e-6 * 111320.0 * math.cos(math.radians((la1 + la2) * 0.5e-6))
    return math.hypot(dx, dy)


def way_info(tags):
    hw = tags.get('highway')
    if hw not in HIGHWAYS:
        return None
    if tags.get('area') == 'yes':
        return None
    if hw == 'service' and tags.get('service') in NO_SERVICE:
        return None
    mv = tags.get('motor_vehicle')
    acc = tags.get('access')
    if mv in ('no', 'private'):
        return None
    if acc in ('no', 'private') and mv not in ('yes', 'permissive', 'designated', 'destination'):
        return None
    if tags.get('motorcycle') == 'no':
        return None
    cls, speed = HIGHWAYS[hw]
    ms = tags.get('maxspeed', '')
    m = re.match(r'\s*(\d{1,3})', ms)
    if m:
        lim = int(m.group(1))
        if 10 <= lim < speed:
            speed = lim
    rb = tags.get('junction') in ('roundabout', 'circular')
    ow = tags.get('oneway', '').lower()
    if ow in ('yes', 'true', '1'):
        d = 1
    elif ow in ('-1', 'reverse'):
        d = 2
    elif ow in ('no', 'false', '0'):
        d = 0
    elif rb or hw in ('motorway', 'motorway_link'):
        d = 1
    else:
        d = 0
    name = (tags.get('name') or tags.get('ref') or '').strip()
    peaje = tags.get('toll') == 'yes'
    return cls, d, rb, name, speed, peaje


class Names:
    def __init__(self):
        self.idx = {}
        self.lst = []

    def get(self, s):
        s = s.strip()
        if not s:
            return -1
        i = self.idx.get(s)
        if i is None:
            i = len(self.lst)
            self.idx[s] = i
            self.lst.append(s)
        return i


def leer_calles(path):
    """Devuelve (ids, lats, lons, ways) con los nodos ordenados por id y las calles útiles."""
    ids = array.array('q')
    lats = array.array('i')
    lons = array.array('i')
    ways = []
    cruces = set()    # nodos con paso a nivel de tren o cabina de peaje
    root = None
    ordenado = True
    for ev, el in ET.iterparse(path, events=('start', 'end')):
        if ev == 'start':
            if root is None:
                root = el
            continue
        t = el.tag
        if t == 'node':
            i = int(el.get('id'))
            if ids and i <= ids[-1]:
                ordenado = False
            ids.append(i)
            lats.append(int(round(float(el.get('lat')) * 1e6)))
            lons.append(int(round(float(el.get('lon')) * 1e6)))
            for x in el.findall('tag'):
                k = x.get('k')
                v = x.get('v')
                if (k == 'railway' and v == 'level_crossing') or (k == 'barrier' and v == 'toll_booth'):
                    cruces.add((i, 1 if k == 'railway' else 2))
            el.clear()
            root.clear()
        elif t == 'way':
            tags = {x.get('k'): x.get('v') for x in el.findall('tag')}
            info = way_info(tags)
            if info is not None:
                refs = [int(x.get('ref')) for x in el.findall('nd')]
                if len(refs) >= 2:
                    ways.append((refs,) + info)
            el.clear()
            root.clear()
        elif t == 'relation':
            el.clear()
            root.clear()
    if not ordenado:
        # por las dudas: ordenar los nodos por id
        orden = sorted(range(len(ids)), key=ids.__getitem__)
        ids = array.array('q', [ids[i] for i in orden])
        lats = array.array('i', [lats[i] for i in orden])
        lons = array.array('i', [lons[i] for i in orden])
    return ids, lats, lons, ways, cruces


def armar_grafo(ids, lats, lons, ways, names, cruces=None):
    n = len(ids)

    def coord(ref):
        i = bisect.bisect_left(ids, ref)
        if i < n and ids[i] == ref:
            return lats[i], lons[i]
        return None

    uso = {}
    for w in ways:
        refs = w[0]
        for r in refs:
            uso[r] = uso.get(r, 0) + 1
        uso[refs[0]] += 1
        uso[refs[-1]] += 1

    vmap = {}
    vlat = array.array('i')
    vlon = array.array('i')

    def vertice(ref, la, lo):
        v = vmap.get(ref)
        if v is None:
            v = len(vlat)
            vmap[ref] = v
            vlat.append(la)
            vlon.append(lo)
        return v

    lA = array.array('i'); lB = array.array('i'); lLen = array.array('i')
    lCost = array.array('i'); lName = array.array('i'); lFlags = array.array('i')
    lStart = array.array('i'); sLat = array.array('i'); sLon = array.array('i')

    tren_nodos = set(i for (i, t) in (cruces or ()) if t == 1)
    peaje_nodos = set(i for (i, t) in (cruces or ()) if t == 2)

    def emitir(a, b, shape, largo, cls, d, rb, nid, speed, extra=0):
        if a == b and not shape and largo < 1.0:
            return
        lA.append(a); lB.append(b)
        m = max(1, int(round(largo)))
        lLen.append(m)
        lCost.append(max(1, int(round(m * 36.0 / speed))))
        lName.append(nid)
        lFlags.append(cls | (d << 4) | ((1 if rb else 0) << 6) | extra)
        lStart.append(len(sLat))
        for (la, lo) in shape:
            sLat.append(la); sLon.append(lo)

    for (refs, cls, d, rb, nombre, speed, peaje) in ways:
        pts = []
        for r in refs:
            c = coord(r)
            if c is not None:
                pts.append((r, c[0], c[1]))
        if len(pts) < 2:
            continue
        nid = names.get(nombre)
        ini = vertice(pts[0][0], pts[0][1], pts[0][2])
        shape = []
        largo = 0.0
        prev = pts[0]
        base = 128 if peaje else 0
        extra = base | (256 if pts[0][0] in tren_nodos else 0) | (128 if pts[0][0] in peaje_nodos else 0)
        for k in range(1, len(pts)):
            p = pts[k]
            largo += dist_m(prev[1], prev[2], p[1], p[2])
            prev = p
            if p[0] in tren_nodos:
                extra |= 256
            if p[0] in peaje_nodos:
                extra |= 128
            if k == len(pts) - 1 or uso.get(p[0], 0) >= 2:
                fin = vertice(p[0], p[1], p[2])
                emitir(ini, fin, shape, largo, cls, d, rb, nid, speed, extra)
                ini = fin
                shape = []
                largo = 0.0
                extra = base | (256 if p[0] in tren_nodos else 0) | (128 if p[0] in peaje_nodos else 0)
            else:
                shape.append((p[1], p[2]))
    lStart.append(len(sLat))
    return vlat, vlon, lA, lB, lLen, lCost, lName, lFlags, lStart, sLat, sLon


def centro(geom):
    """Punto representativo de una geometría GeoJSON (punto o promedio del primer anillo)."""
    t = geom.get('type')
    c = geom.get('coordinates')
    if t == 'Point':
        return c[1], c[0]
    if t == 'Polygon':
        ring = c[0]
    elif t == 'MultiPolygon':
        ring = c[0][0]
    elif t == 'LineString':
        ring = c
    else:
        return None
    if not ring:
        return None
    return (sum(p[1] for p in ring) / len(ring), sum(p[0] for p in ring) / len(ring))


def tipo_lugar(p):
    """Clasifica un lugar con nombre. 0 otro,1 comercio,2 comida,3 salud,4 transporte,5 combustible,
    6 educación,7 parque y ocio,8 barrio o localidad,9 servicios,10 turismo y cultura. None = ignorar."""
    if 'place' in p:
        if p['place'] in ('suburb', 'neighbourhood', 'quarter', 'town', 'village', 'city', 'locality', 'hamlet', 'borough', 'city_block'):
            return 8
        return None
    am = p.get('amenity')
    if p.get('railway') in ('station', 'halt') or p.get('public_transport') == 'station' or am in ('bus_station', 'ferry_terminal'):
        return 4
    if am == 'fuel':
        return 5
    if am in ('restaurant', 'cafe', 'fast_food', 'bar', 'pub', 'ice_cream', 'food_court', 'biergarten'):
        return 2
    if am in ('hospital', 'clinic', 'pharmacy', 'doctors', 'dentist') or 'healthcare' in p:
        return 3
    if am in ('school', 'university', 'college', 'kindergarten', 'library'):
        return 6
    if am in ('bank', 'atm', 'post_office', 'police', 'townhall', 'fire_station', 'courthouse'):
        return 9
    if 'shop' in p:
        return 1
    if 'leisure' in p:
        return 7
    if 'tourism' in p or 'historic' in p:
        return 10
    if 'office' in p:
        return 9
    if am:
        return 0
    return None


def num_de(s):
    m = re.search(r'\d+', s or '')
    if not m:
        return None
    v = int(m.group(0))
    return v if 0 < v < 100000 else None


def leer_lugares(path, names):
    addrs = []
    pois = []
    vistos = set()
    if not path:
        return addrs, pois
    with open(path, encoding='utf-8') as f:
        for linea in f:
            linea = linea.strip().strip('\x1e').strip()
            if not linea:
                continue
            try:
                ft = json.loads(linea)
            except ValueError:
                continue
            p = ft.get('properties') or {}
            g = ft.get('geometry') or {}
            c = centro(g)
            if c is None:
                continue
            la = int(round(c[0] * 1e6))
            lo = int(round(c[1] * 1e6))
            calle = (p.get('addr:street') or '').strip()
            num = num_de(p.get('addr:housenumber'))
            if calle and num is not None:
                addrs.append((names.get(calle), num, la, lo))
            nombre = (p.get('name') or '').strip()
            if nombre:
                k = tipo_lugar(p)
                if k is not None:
                    clave = (nombre.lower(), la // 500, lo // 500)
                    if clave not in vistos:
                        vistos.add(clave)
                        pois.append((nombre[:80], k, la, lo))
    addrs.sort()
    return addrs, pois


def blob(textos):
    """Devuelve (offsets, bytes con relleno a múltiplo de 4)."""
    off = array.array('i')
    out = bytearray()
    for t in textos:
        off.append(len(out))
        out += t.encode('utf-8')
    off.append(len(out))
    while len(out) % 4:
        out.append(0)
    return off, bytes(out)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    calles = sys.argv[1]
    lugares = sys.argv[2] if len(sys.argv) > 3 else None
    salida = sys.argv[-1]
    if sys.byteorder != 'little':
        raise SystemExit('Se necesita una máquina little endian')

    names = Names()
    ids, lats, lons, ways, cruces = leer_calles(calles)
    print('nodos', len(ids), 'calles', len(ways))
    (vlat, vlon, lA, lB, lLen, lCost, lName, lFlags, lStart, sLat, sLon) = armar_grafo(ids, lats, lons, ways, names, cruces)
    print('vertices', len(vlat), 'tramos', len(lA), 'puntos intermedios', len(sLat))
    addrs, pois = leer_lugares(lugares, names)
    print('direcciones', len(addrs), 'lugares', len(pois))

    nameOff, nameBytes = blob(names.lst)
    poiOff, poiBytes = blob([p[0] for p in pois])

    if len(vlat) == 0:
        raise SystemExit('No hay calles: el archivo de entrada está vacío')
    minLat, maxLat = min(vlat), max(vlat)
    minLon, maxLon = min(vlon), max(vlon)

    head = array.array('i', [MAGIC, VERSION, len(vlat), len(lA), len(sLat), len(names.lst),
                             len(nameBytes) // 4, len(addrs), len(pois), len(poiBytes) // 4,
                             minLat, minLon, maxLat, maxLon])
    with open(salida, 'wb') as f:
        for arr in (head, vlat, vlon, lA, lB, lLen, lCost, lName, lFlags, lStart, sLat, sLon, nameOff):
            arr.tofile(f)
        f.write(nameBytes)
        for k in range(4):
            array.array('i', [a[k] for a in addrs]).tofile(f)
        array.array('i', [p[2] for p in pois]).tofile(f)
        array.array('i', [p[3] for p in pois]).tofile(f)
        array.array('i', [p[1] for p in pois]).tofile(f)
        poiOff.tofile(f)
        f.write(poiBytes)
    import os
    print('listo', salida, os.path.getsize(salida) // 1024, 'KB')


if __name__ == '__main__':
    main()
